# Penny Radar 🪙

A personal web app that tracks **Home Depot penny items** and **Home Depot / Lowe's deep clearance**, scores how likely each item is to scan at $0.01, and pushes alerts to your phone.

## What it watches

| Source | What it gives you | How often |
|---|---|---|
| **PennyCentral Penny List** | Community-confirmed HD penny finds, with how many states reported each one | Hourly |
| **Reddit** (r/HomeDepot, r/Lowes by default) | New posts mentioning penny prices; flags posts mentioning your area and any SKUs in them | Every 30 min |
| **Slickdeals** (Hot Deals + Frontpage RSS) | Home Depot / Lowe's penny and in-store clearance (YMMV) posts, often with full SKU / Internet # | Every 30 min |
| **BudgetLightForum** "Home Depot Deal Alerts" thread | Long-running thread of penny and .03 finds | Every 30 min |
| **Slickdeals "price mistake" search** | ⚡ Amazon price glitches (checked every 5 min) | Every 5 min |
| **Any RSS/Atom feed you add** | Settings → Sources → Feeds, one per line: `Name \| URL \| store` | Every 30 min |
| **Your watchlist** | Items you spotted on clearance. Log the tag price and tag date, and the app predicts the penny window | Hourly re-score |

Scavenger.ai has no API, so it isn't polled. Every Home Depot item links to it so you can check stock nearby before you drive out. Lowe's items link to BrickSeek, whose inventory checker is reported to be most accurate for Lowe's.

Forum posts are kept only when they're about Home Depot or Lowe's and mention a penny or clearance price. "HD" counts as Home Depot only in store context ("at HD", "HD clearance"), so "4K HD TV" doesn't match. The **Forums** tab shows everything kept and can filter to Penny, Clearance, Lowe's, or your area. A status line shows which feeds are working.

**Manual-only communities** (no feed an app can read): the *Home Depot One Cent Items* Facebook group (PennyCentral already collects its finds), the Garage Journal "Home Depot deals/sales/clearance" thread, and the various Discord servers. Turn on notifications in the ones you join.

## Alerts you'll get

- 🎯 **Urgent:** a SKU on your watchlist appears on the Penny List, or in a Reddit post
- 💰 **Urgent:** a watchlist item enters its predicted penny window ("Go check now")
- ⏳ **High:** a watchlist item hits final markdown (.03 / .02)
- 🪙 **New on the Penny List:** sent if the item matches one of your keywords (Milwaukee, DeWalt, cooler…) or is already reported in 5+ states
- 📈 **Spreading:** a Penny List item gains 3+ states, which usually means a chain-wide penny
- 💬 **Reddit / forum penny post:** urgent if it mentions your area or a SKU you're watching
- ⚡ **Amazon glitch (urgent, comes through quiet hours):** a post calls it a price mistake/glitch, or the price is ≥85% below another price in the post, or an Amazon item shows for $0.01. Links to Keepa and camelcamelcamel price history so you can sanity-check in seconds. Ordinary Amazon deals are ignored. Add `walmart` or `any` under Settings → Glitch stores to widen it.
- 🏷️ **Forum clearance post:** only when it matches one of your keywords, unless you turn on "push all clearance" in Settings
- ☀️ **Daily digest** at 7:30. Quiet hours (22:00–07:00) hold non-urgent alerts until morning.

On the first fetch, the app records what's already on the list without alerting, so you won't get a flood of old items.

## Penny score (0–100)

| Signal | Points |
|---|---|
| Tag ending: $0.01 | 100 |
| Tag ending: .03/.02 (final) | +60 |
| Tag ending: .06/.04 (mid) | +30 |
| Tag ending: .00 (initial) | +12 |
| Inside predicted penny window | +20 |
| Window opens within 7 days | +10 |
| On the PennyCentral list | +25, plus 1 per state (up to +10) |
| HD app shows "not found" / no price while the item is on the shelf | +15 |
| Reddit mention | +8 |
| Unavailable online | +5 |
| Lowe's item | score × 0.6 (Lowe's rarely sells penny items) |

Cadences come from community observation, not official HD policy:

- **Cadence A:** .00 → .06 (~6 wk) → .03 (~3 wk) → $0.01
- **Cadence B:** .00 → .04 (~4 wk) → .02 (~2 wk) → $0.01

Treat the predicted dates as planning windows, not guarantees.

## Run it

**Option 1: Node (your PC)**

```bash
npm install
npm start            # http://localhost:8787
npm test             # 18 tests
```

**Option 2: Docker (PC, NAS, Raspberry Pi)**

```bash
docker build -t penny-radar .
docker run -d --name penny-radar -p 8787:8787 -v penny-data:/data \
  -e APP_PASSWORD=choose-one --restart unless-stopped penny-radar
```

**Option 3: Azure App Service (Linux, Node 22).** Deploy the folder, then set:

- `APP_PASSWORD` (required once the app is public)
- `DATA_DIR=/home/data` (persistent storage)
- `TZ=America/New_York`
- Always On = enabled, so the poller keeps running

## Get alerts on your phone (2 minutes)

1. Install **ntfy** from the App Store or Play Store.
2. In the app, subscribe to a hard-to-guess topic, e.g. `khwaja-penny-8f3k2`. Anyone who knows the topic can read it.
3. In Penny Radar, go to **Settings**, enable ntfy, enter the same topic, save, then tap **Send test alert**.

You can use Telegram instead or as well: create a bot with @BotFather and paste the bot token and your chat ID.

To install the dashboard itself on your phone, open it in your phone's browser and use **Add to Home Screen**. To reach it away from home, use Tailscale (free) or the Azure option.

## Reddit reliability

Reddit often blocks anonymous requests. If the Reddit dot in the dashboard turns red:

1. Go to https://www.reddit.com/prefs/apps and create a **script** app.
2. Paste its client ID and secret into Settings → Sources.

## Files

```
src/server.js            API + dashboard host
src/jobs.js              scheduler, diffing, alert rules
src/engine/cadence.js    tag decoder, penny-window prediction, scoring
src/sources/*.js         PennyCentral parser, Reddit client, RSS/Atom feeds (Slickdeals, BLF…)
src/watchlist.js         your tracked items + observations
src/notify.js            ntfy / Telegram, quiet hours, digest
public/                  mobile-first dashboard (PWA)
data/                    settings.json + db.json (created at runtime)
```

## Notes

- **Glitches:** a store can cancel a price-mistake order, and often does. Buy quickly if you want to, but don't count on it shipping. For the fastest possible alert, also set up a free Slickdeals Deal Alert for "price mistake" in the Slickdeals app; Penny Radar checks its feed every 5 minutes.

- PennyCentral has no API, so the app reads its public page once an hour. If PennyCentral changes its layout, the dashboard shows a red status with the error. Re-run the parser tests against a saved copy of the page and adjust `src/sources/pennycentral.js`.
- Home Depot doesn't publish a penny policy. A store can decline to sell a penny item, so be polite and don't pressure staff.

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const { parseHtml } = require('../src/sources/pennycentral');
const { classify, fromJson, fromRss, extractSkus } = require('../src/sources/reddit');

const fx = (f) => fs.readFileSync(path.join(__dirname, 'fixtures', f), 'utf8');

test('parses PennyCentral cards', () => {
  const items = parseHtml(fx('pennylist.html'));
  assert.equal(items.length, 2);
  const a = items.find((i) => i.sku === '1012388248');
  assert.equal(a.skuDisplay, '1012-388-248');
  assert.equal(a.states, 14);
  assert.equal(a.reports, 23);
  assert.equal(a.lastSeen, 'Yesterday');
  assert.match(a.name, /Tripod Work Light/);
  assert.equal(a.image, 'https://images.thdstatic.com/productimages/abc.jpg');
  const b = items.find((i) => i.sku === '215583');
  assert.equal(b.skuDisplay, '215-583');
  assert.equal(b.states, 2);
});

test('falls back to embedded JSON', () => {
  const items = parseHtml(fx('pennylist-next.html'));
  assert.equal(items.length, 1);
  assert.equal(items[0].states, 9);
  assert.equal(items[0].name, 'Contractor Grade Garden Hose');
});

const cfg = { keywords: ['penny', '$0.01', '1 cent', '1¢'], localKeywords: ['ohio', 'columbus'] };

test('classifies reddit posts', () => {
  const posts = fromJson(JSON.stringify({ data: { children: [
    { data: { name: 't3_a', title: 'First time finding a penny item!', selftext: 'Columbus store, SKU 1012-388-248', permalink: '/r/HomeDepot/comments/a/', created_utc: 1763600000 } },
    { data: { name: 't3_b', title: 'Pennyworth is a great show', selftext: '', permalink: '/r/x/', created_utc: 1763600000 } },
    { data: { name: 't3_c', title: 'Rang up $0.01 lol', selftext: '', permalink: '/r/x/', created_utc: 1763600000 } },
  ] } }), 'HomeDepot').map((p) => classify(p, cfg));
  assert.equal(posts[0].isPenny, true);
  assert.equal(posts[0].isLocal, true);
  assert.deepEqual(posts[0].skus, ['1012388248']);
  assert.equal(posts[1].isPenny, false, 'should not match "Pennyworth"');
  assert.equal(posts[2].isPenny, true);
});

test('parses reddit RSS', () => {
  const xml = `<?xml version="1.0"?><feed xmlns="http://www.w3.org/2005/Atom"><entry><id>t3_z</id><title>Penny cooler found</title><link href="https://www.reddit.com/r/HomeDepot/comments/z/"/><updated>2026-11-19T10:00:00+00:00</updated><author><name>/u/someone</name></author><content type="html">&lt;p&gt;in Ohio&lt;/p&gt;</content></entry></feed>`;
  const [p] = fromRss(xml, 'HomeDepot');
  assert.equal(p.id, 't3_z');
  assert.equal(p.author, 'someone');
  assert.equal(classify(p, cfg).isLocal, true);
});

test('extracts SKUs', () => {
  assert.deepEqual(extractSkus('sku 215-583 and 1001234567 and internet 206475885'), ['215583', '1001234567', '206475885']);
});

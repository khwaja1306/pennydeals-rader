// End-to-end: run jobs against mocked HTTP and check what gets pushed.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'penny-'));
const config = require('../src/config');
const store = require('../src/store');
const jobs = require('../src/jobs');
const watchlist = require('../src/watchlist');

let pages = {};
const pushed = [];
global.fetch = async (url, opts = {}) => {
  if (String(url).startsWith('https://ntfy.sh')) { pushed.push(JSON.parse(opts.body)); return new Response('{}'); }
  const body = pages[url];
  if (body === undefined) return new Response('nope', { status: 404 });
  return new Response(body);
};

const PC = 'https://www.pennycentral.com/penny-list';
const card = (sku, name, states) => `<div class="card"><a href="/sku/${sku}"><img alt="${name}" src="/x.jpg"/></a><div>${states} states</div><div>3 reports</div></div>`;

test('pipeline: seed silently, then alert on new / spread / watch hit', async () => {
  config.load(); store.load();
  const s = config.get();
  s.notify.ntfy = { enabled: true, server: 'https://ntfy.sh', topic: 'test-topic', token: '' };
  s.notify.quietHours.enabled = false;
  s.keywords = ['milwaukee'];
  config.save(s);

  pages[PC] = card('1000000001', 'Some Bracket', 2);
  let r = await jobs.runPennyCentral();
  assert.equal(r.ok, true); assert.equal(r.firstRun, true);
  assert.equal(pushed.length, 0, 'first run seeds without alerts');

  watchlist.add({ sku: '1000000003', name: 'My Faucet', storeName: 'Polaris' });
  pages[PC] = card('1000000001', 'Some Bracket', 6) + card('1000000002', 'Milwaukee M18 Light', 1) + card('1000000003', 'Faucet', 1) + card('1000000004', 'Boring Thing', 2);
  r = await jobs.runPennyCentral();
  const titles = pushed.map((p) => p.title);
  assert.ok(titles.some((t) => t.startsWith('Spreading: Some Bracket')), titles.join(' | '));
  assert.ok(titles.some((t) => t.includes('New penny: Milwaukee M18 Light')), 'keyword match pushes');
  assert.ok(titles.some((t) => t.includes('Watchlist item is PENNY somewhere: My Faucet')));
  assert.ok(!titles.some((t) => t.includes('Boring Thing')), 'low-state non-keyword item not pushed');
  assert.equal(pushed.find((p) => p.title.includes('My Faucet')).priority, 5);

  const n = pushed.length;
  await jobs.runPennyCentral();
  assert.equal(pushed.length, n, 'no duplicate alerts on unchanged list');
});

test('watchlist: final markdown + window alerts', async () => {
  const it = watchlist.add({ sku: '555555', name: 'Shop Vac', storeName: 'Lewis Center' });
  watchlist.addObservation(it.id, { price: 39.03, tagDate: '2026-11-01', date: '2026-11-05' });
  const before = pushed.length;
  await jobs.runWatchlist(new Date('2026-11-25T12:00:00'));
  const got = pushed.slice(before).map((p) => p.title);
  assert.ok(got.some((t) => t.startsWith('Final markdown: Shop Vac')), got.join(' | '));
  assert.ok(got.some((t) => t.startsWith('Go check now: Shop Vac')));
  await jobs.runWatchlist(new Date('2026-11-25T13:00:00'));
  assert.equal(pushed.length, before + got.length, 'deduped');
});

test('quiet hours hold non-urgent alerts and flush as a digest', async () => {
  const notify = require('../src/notify');
  const s = config.get(); s.notify.quietHours = { enabled: true, start: '00:00', end: '23:59' }; s.notify.dailyDigest.enabled = false; config.save(s);
  const before = pushed.length;
  const e = await notify.alert({ key: 'q1', title: 'held one', message: 'x', priority: 'normal' });
  assert.equal(e.status, 'held (quiet hours)');
  const u = await notify.alert({ key: 'q2', title: 'urgent one', message: 'x', priority: 'urgent' });
  assert.equal(u.status, 'pushed');
  s.notify.quietHours.enabled = false; config.save(s);
  await notify.maintenance(new Date());
  const last = pushed.at(-1);
  assert.match(last.title, /Overnight: 1 penny alert/);
  assert.equal(pushed.length, before + 2);
  store.flush();
});

test('feeds job: seeds silently, then pushes penny / watched / keyword clearance only', async () => {
  const s = config.get();
  s.notify.quietHours.enabled = false;
  s.keywords = ['milwaukee'];
  s.sources.feeds.list = [{ name: 'SD', url: 'https://example.test/sd.rss', enabled: true }];
  config.save(s);
  const item = (id, title, desc) => `<item><title>${title}</title><link>https://sd/${id}</link><guid>${id}</guid><pubDate>Thu, 19 Nov 2026 10:00:00 +0000</pubDate><description>${desc}</description></item>`;
  const rss = (...items) => `<?xml version="1.0"?><rss version="2.0"><channel>${items.join('')}</channel></rss>`;
  pages['https://example.test/sd.rss'] = rss(item('a', 'Old penny at Home Depot $0.01', 'x'));
  let r = await jobs.runFeeds();
  assert.equal(r.ok, true);
  const before = pushed.length;
  assert.equal(pushed.length, before);

  watchlist.add({ sku: '1012825716', name: 'Backerboard knife' });
  pages['https://example.test/sd.rss'] = rss(
    item('a', 'Old penny at Home Depot $0.01', 'x'),
    item('b', 'Folding knife $0.01 Home Depot', 'SKU 1012825716'),
    item('c', 'Husky tool set $55 Home Depot YMMV clearance', 'in store'),
    item('d', 'Milwaukee M12 light $9 Home Depot clearance', 'ymmv'),
    item('e', 'Toilet $0.01 at Home Depot', 'found today'),
  );
  r = await jobs.runFeeds();
  const got = pushed.slice(before);
  const titles = got.map((p) => p.title);
  assert.equal(r.fresh, 4);
  assert.ok(titles.some((t) => t.startsWith('🎯 Penny (HD): Folding knife')), titles.join(' | '));
  assert.equal(got.find((p) => p.title.includes('Folding knife')).priority, 5);
  assert.ok(titles.some((t) => t.includes('Toilet')), 'penny posts push');
  assert.ok(titles.some((t) => t.startsWith('Clearance (HD): Milwaukee')), 'keyword clearance pushes');
  assert.ok(!titles.some((t) => t.includes('Husky')), 'non-keyword clearance stays on dashboard');
  assert.ok(!titles.some((t) => t.includes('Old penny')), 'seeded post not re-sent');
});

test('feeds job: Amazon glitch is urgent; per-feed intervals respected', async () => {
  const s = config.get();
  s.notify.quietHours = { enabled: true, start: '00:00', end: '23:59' }; // glitch should still push (urgent)
  s.sources.feeds.list = [
    { name: 'PM', url: 'https://example.test/pm.rss', everyMinutes: 5, enabled: true },
    { name: 'Slow', url: 'https://example.test/slow.rss', everyMinutes: 60, enabled: true },
  ];
  config.save(s);
  const item = (id, title, desc) => `<item><title>${title}</title><link>https://sd/${id}</link><guid>${id}</guid><pubDate>Thu, 19 Nov 2026 10:00:00 +0000</pubDate><description>${desc}</description></item>`;
  const rss = (...items) => `<?xml version="1.0"?><rss version="2.0"><channel>${items.join('')}</channel></rss>`;
  pages['https://example.test/pm.rss'] = rss();
  pages['https://example.test/slow.rss'] = rss();
  const t0 = Date.now();
  await jobs.runFeeds({ onlyDue: true, now: t0 }); // seeds both
  const before = pushed.length;
  pages['https://example.test/pm.rss'] = rss(item('g1', 'Sony camera bundle $94.48 at Amazon', 'Price mistake! Normally $13,000'));
  pages['https://example.test/slow.rss'] = rss(item('h1', 'Penny drill at Home Depot $0.01', 'x'));
  const r = await jobs.runFeeds({ onlyDue: true, now: t0 + 6 * 60000 });
  assert.equal(r.perFeed.PM.ok, true);
  assert.equal(r.perFeed.Slow, undefined, 'slow feed not due yet');
  const got = pushed.slice(before);
  assert.equal(got.length, 1);
  assert.match(got[0].title, /^⚡ Amazon glitch: Sony camera bundle/);
  assert.equal(got[0].priority, 5);
  s.notify.quietHours.enabled = false; config.save(s);
});

test('settings migration adds new built-in feeds once, not deleted ones', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'penny-mig-'));
  fs.writeFileSync(path.join(dir, 'settings.json'), JSON.stringify({ sources: { feeds: { list: [
    { name: 'Slickdeals Hot Deals', url: 'https://slickdeals.net/newsearch.php?searchin=first&forumchoice%5B%5D=9&rss=1' },
  ] } } }));
  const { execFileSync } = require('child_process');
  const out = execFileSync(process.execPath, ['-e', `const c=require(${JSON.stringify(path.join(__dirname, '..', 'src', 'config.js'))}); console.log(JSON.stringify(c.load().sources.feeds.list.map(f=>f.name)))`], { env: { ...process.env, DATA_DIR: dir } }).toString();
  const names = JSON.parse(out);
  assert.ok(names.includes('Slickdeals price mistakes'), names.join(','));
  assert.ok(!names.includes('BudgetLightForum HD thread'), 'user had removed BLF before — stays removed');
});

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const { parseFeed, classify, relevant, titlePrice } = require('../src/sources/feeds');

const cfg = { pennyKeywords: ['penny', '$0.01', '1 cent'], localKeywords: ['ohio', 'columbus'] };
const xml = fs.readFileSync(path.join(__dirname, 'fixtures', 'slickdeals.rss'), 'utf8');

test('parses + classifies Slickdeals RSS', () => {
  const feed = { name: 'SD' };
  const posts = parseFeed(xml, 'SD').map((p) => classify(p, feed, cfg));
  const byId = Object.fromEntries(posts.map((p) => [p.id, p]));
  const knife = byId['SD:sd-1'];
  assert.equal(knife.store, 'homedepot');
  assert.equal(knife.isPenny, true);
  assert.equal(knife.price, 0.01);
  assert.equal(knife.isLocal, true);
  assert.deepEqual(knife.skus, ['1012825716']);
  assert.equal(byId['SD:sd-2'].store, 'homedepot');
  assert.equal(byId['SD:sd-2'].isClearance, true);
  assert.equal(byId['SD:sd-2'].isPenny, false);
  assert.equal(byId['SD:sd-3'].store, 'lowes');
  assert.equal(byId['SD:sd-4'].store, null, 'lowercase "hd" must not count as Home Depot');
  const kept = posts.filter((p) => relevant(p, feed)).map((p) => p.id);
  assert.deepEqual(kept, ['SD:sd-1', 'SD:sd-2', 'SD:sd-3'], 'non-store and non-clearance posts dropped');
});

test('store-specific feed (BLF thread) keeps posts without store names', () => {
  const atom = `<?xml version="1.0"?><rss version="2.0"><channel><item><title>Re: Home Depot Deal Alerts</title><link>https://budgetlightforum.com/t/x/27168/5000</link><guid>blf-1</guid><pubDate>Thu, 19 Nov 2026 10:00:00 +0000</pubDate><description>&lt;p&gt;These lanterns are $4.03 now, should hit a penny soon&lt;/p&gt;</description></item></channel></rss>`;
  const feed = { name: 'BLF', store: 'homedepot' };
  const [p] = parseFeed(atom, 'BLF').map((x) => classify(x, feed, cfg));
  assert.equal(p.store, 'homedepot');
  assert.equal(p.isClearance, true);
  assert.equal(p.isPenny, true);
  assert.ok(relevant(p, feed));
});

test('titlePrice', () => {
  assert.equal(titlePrice('Knife $0.01'), 0.01);
  assert.equal(titlePrice('Knife $.01'), 0.01);
  assert.equal(titlePrice('Set $1,299.99 at HD'), 1299.99);
  assert.equal(titlePrice('no price'), null);
});

test('Amazon glitch detection', () => {
  const cfg2 = { ...cfg, glitchStores: ['amazon'], glitchMinDiscount: 85 };
  const feed = { name: 'SD' };
  const mk = (title, body = '') => classify({ title, body, id: title }, feed, cfg2);
  const scooter = mk('Segway Ninebot Max Electric Kick Scooter $60', 'Amazon listing, list price $799 https://www.amazon.com/dp/B07KKQ7K5T');
  assert.equal(scooter.store, 'amazon');
  assert.equal(scooter.isGlitch, true);
  assert.equal(scooter.discountPct, 92);
  assert.equal(scooter.asin, 'B07KKQ7K5T');
  assert.ok(relevant(scooter, feed, cfg2));

  const pm = mk('Dobyns casting rod $106 at Amazon', 'Appears to be a price mistake on Amazon. Retails for over $200.');
  assert.equal(pm.isGlitch, true, 'price-mistake wording counts');

  const normal = mk('Anker charger $19.99 at Amazon', 'was $29.99');
  assert.equal(normal.isGlitch, false);
  assert.equal(relevant(normal, feed, cfg2), false, 'ordinary Amazon deals are not kept');

  const wm = mk('Walmart TV $50 price mistake', 'reg $1,499');
  assert.equal(wm.isGlitch, true);
  assert.equal(relevant(wm, feed, cfg2), false, 'Walmart not in glitch stores by default');
  assert.equal(relevant(wm, feed, { ...cfg2, glitchStores: ['any'] }), true);
});

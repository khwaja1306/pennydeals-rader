const test = require('node:test');
const assert = require('node:assert');
const { decodeHD, decodeLowes, predict, score } = require('../src/engine/cadence');

test('decodes Home Depot price endings', () => {
  assert.equal(decodeHD(0.01).stage, 'penny');
  assert.equal(decodeHD(37.03).stage, 'final');
  assert.equal(decodeHD(37.03).cadence, 'A');
  assert.equal(decodeHD(12.02).cadence, 'B');
  assert.equal(decodeHD(24.06).stage, 'second');
  assert.equal(decodeHD(24.04).cadence, 'B');
  assert.equal(decodeHD(30.00).stage, 'initial');
  assert.equal(decodeHD(30.00, { clearance: false }).stage, 'regular');
  assert.equal(decodeHD(29.97).stage, 'regular');
  assert.equal(decodeHD(19.56).stage, 'other');
});

test('predicts penny window from tag date', () => {
  const p = predict(decodeHD(10.03), '2026-11-01');
  assert.equal(p.pennyFrom.toISOString().slice(0, 10), '2026-11-22'); // +3 weeks
  const q = predict(decodeHD(10.06), '2026-11-01');
  assert.equal(q.nextMarkdown.toISOString().slice(0, 10), '2026-12-13'); // +6 weeks
  assert.equal(q.pennyFrom.toISOString().slice(0, 10), '2027-01-03');   // +3 more
});

test('scores signals sensibly', () => {
  const d = decodeHD(10.03);
  const pr = predict(d, '2026-11-01');
  const low = score({ decoded: decodeHD(10.06), now: '2026-11-02' }).score;
  const inWindow = score({ decoded: d, prediction: pr, now: '2026-11-25' }).score;
  const strong = score({ decoded: d, prediction: pr, now: '2026-11-25', pcStates: 6, appNotFound: true }).score;
  assert.ok(low < inWindow && inWindow < strong, `${low} < ${inWindow} < ${strong}`);
  assert.equal(score({ decoded: decodeHD(0.01) }).score, 100);
  assert.ok(strong <= 99);
  const lowes = score({ decoded: decodeLowes(20, 100), store: 'lowes' });
  assert.ok(lowes.score < 60);
});

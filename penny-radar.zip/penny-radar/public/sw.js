// Minimal service worker so the dashboard can be installed to the home screen.
// Network-first: data must always be fresh; the shell falls back to cache offline.
const CACHE = 'penny-radar-v1';
const SHELL = ['/', '/index.html', '/style.css', '/app.js', '/icon.svg', '/manifest.json'];
self.addEventListener('install', (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.pathname.startsWith('/api/')) return;
  e.respondWith(fetch(e.request).then((r) => { caches.open(CACHE).then((c) => c.put(e.request, r.clone())); return r; }).catch(() => caches.match(e.request)));
});

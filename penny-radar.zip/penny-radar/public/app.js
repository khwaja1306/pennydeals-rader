/* Penny Radar dashboard (vanilla JS, no build step). */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...opts, body: opts.body ? JSON.stringify(opts.body) : undefined });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || res.statusText);
  return res.json();
}

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg; document.body.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

function ago(iso) {
  if (!iso) return '—';
  const s = (Date.now() - new Date(iso)) / 1000;
  if (s < 60) return 'just now'; if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`; return `${Math.round(s / 86400)}d ago`;
}
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
const money = (n) => n == null ? '' : `$${Number(n).toFixed(2)}`;
const sparks = '▁▂▃▄▅▆▇█';
function spark(arr) {
  const v = (arr || []).filter((x) => x != null); if (v.length < 2) return '';
  const max = Math.max(...v), min = Math.min(...v);
  return v.slice(-12).map((x) => sparks[max === min ? 3 : Math.round(((x - min) / (max - min)) * 7)]).join('');
}
function scoreEl(n) { return `<div class="score ${n >= 70 ? 'hi' : n >= 40 ? 'mid' : 'lo'}" title="Penny likelihood">${n}</div>`; }
function storeBadge(s) { return s === 'lowes' ? '<span class="badge lowes">LOWE\'S</span>' : '<span class="badge hd">HOME DEPOT</span>'; }
function linkRow(l = {}) {
  return `<div class="links">
    ${l.store ? `<a href="${esc(l.store)}" target="_blank" rel="noopener">Store site</a>` : ''}
    ${l.pennycentral ? `<a href="${esc(l.pennycentral)}" target="_blank" rel="noopener">PennyCentral</a>` : ''}
    ${l.scavenger ? `<a href="${esc(l.scavenger)}" target="_blank" rel="noopener">Check stock on Scavenger</a>` : ''}
    ${l.brickseek ? `<a href="${esc(l.brickseek)}" target="_blank" rel="noopener">BrickSeek (Lowe's stock)</a>` : ''}
  </div>`;
}
function windowLine(p) {
  if (!p) return '';
  return `<div class="window">${p.nextMarkdown ? `Next markdown ~<b>${fmtDate(p.nextMarkdown)}</b> · ` : ''}Penny window <b>${fmtDate(p.pennyFrom)} – ${fmtDate(p.pennyTo)}</b></div>`;
}

// ---------- tabs ----------
const loaders = {};
function showTab(name) {
  if (!document.getElementById(`tab-${name}`)) name = 'hunt';
  $$('#tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  $$('.tab').forEach((t) => t.classList.toggle('active', t.id === `tab-${name}`));
  location.hash = name;
  loaders[name]?.();
}
$('#tabs').addEventListener('click', (e) => { if (e.target.dataset.tab) showTab(e.target.dataset.tab); });
document.addEventListener('click', (e) => {
  const s = e.target.closest('.sku');
  if (s) { navigator.clipboard?.writeText(s.textContent.replace(/\D/g, '')); toast('SKU copied — paste it into the store app'); }
});

// ---------- status ----------
async function loadStatus() {
  try {
    const s = await api('/api/status');
    const dot = (ok) => `<span class="dot" style="background:${ok ? 'var(--good)' : 'var(--bad)'}"></span>`;
    $('#health').innerHTML =
      `${dot(!s.pennycentral.lastError)}List ${ago(s.pennycentral.lastFetch)}` +
      `${dot(!s.reddit.lastError)}Reddit ${ago(s.reddit.lastFetch)}` +
      `${dot(!s.feeds.lastError)}Forums ${ago(s.feeds.lastFetch)}` +
      `${dot(s.notify.ntfy || s.notify.telegram)}${s.notify.ntfy || s.notify.telegram ? 'Alerts on' : 'Alerts off'}`;
  } catch { $('#health').textContent = 'offline'; }
}

// ---------- hunt ----------
loaders.hunt = async () => {
  const items = await api('/api/hunt');
  const watchOnly = $('#hunt-watch-only').checked;
  const list = items.filter((i) => !watchOnly || i.type === 'watch');
  $('#hunt-list').innerHTML = list.length ? list.map((i) => `
    <div class="card">
      ${i.image ? `<img class="thumb" src="${esc(i.image)}" alt="" loading="lazy" />` : ''}
      <div class="body">
        <p class="title">${esc(i.name)}</p>
        <div class="meta">${storeBadge(i.store)} ${i.isNew ? '<span class="badge new">NEW</span>' : ''}
          ${i.type === 'watch' ? '<span class="badge">WATCHING</span>' : ''}
          ${i.sku ? `<span class="sku" title="tap to copy">${esc(i.sku)}</span>` : ''}
          ${i.states ? `<span>${i.states} states</span>` : ''} ${i.storeName ? `<span>📍 ${esc(i.storeName)}</span>` : ''}
          ${i.latest ? `<span>last ${money(i.latest.price)} on ${fmtDate(i.latest.date)}</span>` : ''}
        </div>
        ${windowLine(i.prediction)}
        <ul class="reasons">${(i.reasons || []).map((r) => `<li>${esc(r)}</li>`).join('')}</ul>
        ${linkRow(i.links)}
      </div>
      ${scoreEl(i.score)}
    </div>`).join('') : '<div class="empty">Nothing yet. Add items to your watchlist, or wait for the first Penny List fetch.</div>';
};
$('#hunt-watch-only').addEventListener('change', loaders.hunt);
$('#hunt-refresh').addEventListener('click', loaders.hunt);

// ---------- pennycentral ----------
loaders.pc = async () => {
  const q = encodeURIComponent($('#pc-q').value);
  const items = await api(`/api/pennycentral?q=${q}&minStates=${$('#pc-min').value}`);
  const dayAgo = Date.now() - 86400000;
  $('#pc-list').innerHTML = items.length ? items.map((i) => `
    <div class="card">
      ${i.image ? `<img class="thumb" src="${esc(i.image)}" alt="" loading="lazy" />` : ''}
      <div class="body">
        <p class="title">${esc(i.name)}</p>
        <div class="meta">
          ${new Date(i.firstSeen) > dayAgo ? '<span class="badge new">NEW</span>' : ''}
          <span class="sku" title="tap to copy">${esc(i.skuDisplay)}</span>
          <span>${i.states ?? '?'} states</span><span>${i.reports ?? '?'} reports</span>
          ${i.lastSeen ? `<span>last seen ${esc(i.lastSeen)}</span>` : ''}
          ${spark(i.trend) ? `<span class="trend" title="states over time">${spark(i.trend)}</span>` : ''}
        </div>
        <div class="links">
          <a href="${esc(i.url)}" target="_blank" rel="noopener">PennyCentral</a>
          <a href="https://www.homedepot.com/s/${esc(i.sku)}" target="_blank" rel="noopener">Home Depot</a>
          <a href="https://scavenger.ai" target="_blank" rel="noopener">Scavenger</a>
          <a href="#" data-watch="${esc(i.sku)}" data-name="${esc(i.name)}">+ Watch</a>
        </div>
      </div>
    </div>`).join('') : '<div class="empty">No items yet. Tap “Fetch now”.</div>';
};
let pcTimer; $('#pc-q').addEventListener('input', () => { clearTimeout(pcTimer); pcTimer = setTimeout(loaders.pc, 250); });
$('#pc-min').addEventListener('change', loaders.pc);
$('#pc-run').addEventListener('click', async () => {
  toast('Fetching Penny List…');
  const r = await api('/api/run/pennycentral', { method: 'POST' });
  toast(r.ok ? `Got ${r.count} items (${r.fresh || 0} new)` : `Error: ${r.error}`);
  loaders.pc(); loadStatus();
});
$('#pc-list').addEventListener('click', async (e) => {
  const a = e.target.closest('[data-watch]'); if (!a) return;
  e.preventDefault();
  const storeName = prompt('Which store will you check? (optional)', '') ?? '';
  await api('/api/watchlist', { method: 'POST', body: { store: 'homedepot', sku: a.dataset.watch, name: a.dataset.name, storeName } });
  toast('Added to watchlist');
});

// ---------- reddit ----------
loaders.reddit = async () => {
  const [posts, st] = await Promise.all([api(`/api/posts?filter=${$('#rd-filter').value}`), api('/api/status')]);
  const pf = Object.entries(st.feeds.perFeed || {});
  $('#feed-health').innerHTML = pf.map(([n, f]) => `${f.ok ? '🟢' : '🔴'} ${esc(n)}${f.ok ? '' : ` — <span class="err">${esc(f.error)}</span>`}`).join(' · ')
    + (st.reddit.lastError ? ` · 🔴 Reddit — <span class="err">${esc(st.reddit.lastError.message)}</span>` : '');
  const storeB = (p) => p.store === 'lowes' ? storeBadge('lowes') : p.store === 'homedepot' ? storeBadge('homedepot')
    : p.store === 'amazon' ? '<span class="badge amazon">AMAZON</span>' : p.store === 'walmart' ? '<span class="badge lowes">WALMART</span>' : '';
  $('#rd-list').innerHTML = posts.length ? posts.map((p) => `
    <div class="item">
      <div><a href="${esc(p.url)}" target="_blank" rel="noopener"><b>${esc(p.title)}</b></a></div>
      <div class="meta" style="margin-top:4px">
        <span class="badge src">${esc(p.source)}</span> ${storeB(p)}
        ${p.isGlitch ? `<span class="badge glitch">⚡ GLITCH${p.discountPct ? ` −${p.discountPct}%` : ''}</span>` : p.isPenny ? '<span class="badge penny">PENNY</span>' : p.isClearance ? '<span class="badge">CLEARANCE</span>' : ''}
        ${p.isLocal ? '<span class="badge local">📍 LOCAL</span>' : ''}
        <span>${ago(p.created)}</span>
        ${p.skus?.length ? '<span>SKUs: ' + p.skus.map((s) => `<span class="sku">${esc(s)}</span>`).join(', ') + '</span>' : ''}
      </div>
      ${p.body ? `<div class="hint">${esc(p.body.slice(0, 240))}${p.body.length > 240 ? '…' : ''}</div>` : ''}
      ${p.asin ? `<div class="links"><a href="https://www.amazon.com/dp/${esc(p.asin)}" target="_blank" rel="noopener">Amazon</a>
        <a href="https://keepa.com/#!product/1-${esc(p.asin)}" target="_blank" rel="noopener">Keepa price history</a>
        <a href="https://camelcamelcamel.com/product/${esc(p.asin)}" target="_blank" rel="noopener">camelcamelcamel</a></div>` : ''}
    </div>`).join('') : '<div class="empty">No matching posts yet. Tap “Fetch now”.</div>';
};
$('#rd-filter').addEventListener('change', loaders.reddit);
$('#rd-run').addEventListener('click', async () => {
  toast('Checking Reddit and forums…');
  const [r, f] = await Promise.all([api('/api/run/reddit', { method: 'POST' }), api('/api/run/feeds', { method: 'POST' })]);
  const errs = [r.ok ? '' : `Reddit: ${r.error}`, ...(f.errors || [])].filter(Boolean);
  toast(errs.length ? `Done with ${errs.length} error(s) — see status line` : `${(r.fresh || 0) + (f.fresh || 0)} new post(s)`);
  loaders.reddit(); loadStatus();
});

// ---------- watchlist ----------
loaders.watch = async () => {
  const items = await api('/api/watchlist');
  $('#watch-list').innerHTML = items.length ? items.map((i) => `
    <div class="card" data-id="${i.id}">
      <div class="body">
        <p class="title">${esc(i.name)} ${i.archived ? '<span class="badge">ARCHIVED</span>' : ''}</p>
        <div class="meta">${storeBadge(i.store)} ${i.sku ? `<span class="sku">${esc(i.sku)}</span>` : ''}
          ${i.storeName ? `<span>📍 ${esc(i.storeName)}</span>` : ''} ${i.originalPrice ? `<span>was ${money(i.originalPrice)}</span>` : ''}
          ${i.onPennyCentral ? '<span class="badge new">ON PENNY LIST</span>' : ''}</div>
        ${i.decoded ? `<div class="window">${money(i.latest.price)} → ${esc(i.decoded.label)}</div>` : '<div class="hint">No price logged yet — tap “Log price”.</div>'}
        ${windowLine(i.prediction)}
        <ul class="reasons">${i.reasons.map((r) => `<li>${esc(r)}</li>`).join('')}</ul>
        <details><summary class="hint">History (${i.observations.length})</summary>
          ${i.observations.map((o) => `<div class="hint">${fmtDate(o.date)}: ${money(o.price)}${o.tagDate ? ` (tag ${fmtDate(o.tagDate)})` : ''}${o.appNotFound ? ' · app not found' : ''}${o.note ? ' · ' + esc(o.note) : ''}</div>`).join('')}
        </details>
        ${linkRow(i.links)}
        <div class="row" style="margin-top:8px">
          <button class="small" data-act="obs">Log price</button>
          <button class="small ghost" data-act="archive">${i.archived ? 'Unarchive' : 'Archive'}</button>
          <button class="small danger" data-act="del">Delete</button>
        </div>
      </div>
      ${scoreEl(i.score)}
    </div>`).join('') : '<div class="empty">Your watchlist is empty. Add clearance items you spot (.06/.04/.03/.02 tags) and log the price each visit.</div>';
};
$('#add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const item = await api('/api/watchlist', { method: 'POST', body: f });
  if (f.price) await api(`/api/watchlist/${item.id}/observations`, { method: 'POST', body: { price: f.price, tagDate: f.tagDate || null } });
  e.target.reset(); $('#add-panel').open = false; toast('Added'); loaders.watch();
});
let obsTarget = null;
$('#watch-list').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const id = b.closest('[data-id]').dataset.id;
  if (b.dataset.act === 'obs') {
    obsTarget = id; $('#obs-form').reset();
    $('#obs-form [name=date]').value = new Date().toISOString().slice(0, 10);
    $('#obs-dialog').showModal();
  } else if (b.dataset.act === 'archive') {
    const archived = b.textContent === 'Archive';
    await api(`/api/watchlist/${id}`, { method: 'PATCH', body: { archived } }); loaders.watch();
  } else if (b.dataset.act === 'del' && confirm('Delete this item?')) {
    await api(`/api/watchlist/${id}`, { method: 'DELETE' }); loaders.watch();
  }
});
$('#obs-dialog').addEventListener('close', async () => {
  if ($('#obs-dialog').returnValue !== 'ok' || !obsTarget) return;
  const fd = new FormData($('#obs-form'));
  const body = Object.fromEntries(fd);
  ['clearance', 'appNotFound', 'onlineUnavailable'].forEach((k) => { body[k] = fd.has(k); });
  await api(`/api/watchlist/${obsTarget}/observations`, { method: 'POST', body });
  toast('Price logged'); loaders.watch();
});

// ---------- penny check ----------
$('#check-form [name=store]').addEventListener('change', (e) => { $('#check-form').dataset.store = e.target.value; });
$('#check-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const p = new URLSearchParams();
  for (const k of ['store', 'sku', 'price', 'tagDate', 'original']) if (fd.get(k)) p.set(k, fd.get(k));
  p.set('appNotFound', fd.has('appNotFound')); p.set('onlineUnavailable', fd.has('onlineUnavailable'));
  const r = await api(`/api/check?${p}`);
  $('#check-result').innerHTML = `
    <div class="card">
      <div class="body">
        <p class="title">${r.decoded ? esc(r.decoded.label) : 'SKU lookup'}</p>
        ${r.skuDisplay ? `<div class="meta"><span class="sku">${esc(r.skuDisplay)}</span></div>` : ''}
        ${windowLine(r.prediction)}
        ${r.pennycentral ? `<div class="window">🟢 On PennyCentral: <b>${r.pennycentral.states ?? '?'} states</b>, ${r.pennycentral.reports ?? '?'} reports${r.pennycentral.lastSeen ? `, last seen ${esc(r.pennycentral.lastSeen)}` : ''}</div>` : r.sku ? '<div class="hint">Not on the Penny List right now.</div>' : ''}
        ${r.reddit.length ? `<div class="window">💬 ${r.reddit.length} Reddit mention(s): ${r.reddit.map((p) => `<a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.title.slice(0, 60))}</a>`).join(' · ')}</div>` : ''}
        <ul class="reasons">${r.reasons.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
        ${linkRow(r.links)}
        ${r.sku && !r.watchlistId ? `<div class="row" style="margin-top:8px"><button class="small" id="check-watch">Add to watchlist</button></div>` : ''}
      </div>
      ${scoreEl(r.score)}
    </div>`;
  $('#check-watch')?.addEventListener('click', async () => {
    const it = await api('/api/watchlist', { method: 'POST', body: { store: r.store, sku: r.sku, name: r.pennycentral?.name || '', originalPrice: fd.get('original') || null } });
    if (fd.get('price')) await api(`/api/watchlist/${it.id}/observations`, { method: 'POST', body: { price: fd.get('price'), tagDate: fd.get('tagDate') || null, appNotFound: fd.has('appNotFound'), onlineUnavailable: fd.has('onlineUnavailable') } });
    toast('Added to watchlist');
  });
});

// ---------- alerts ----------
loaders.alerts = async () => {
  const a = await api('/api/alerts');
  $('#alert-list').innerHTML = a.length ? a.map((x) => `
    <div class="item">
      <div>${x.url ? `<a href="${esc(x.url)}" target="_blank" rel="noopener"><b>${esc(x.title)}</b></a>` : `<b>${esc(x.title)}</b>`}</div>
      <div class="when">${ago(x.at)} · ${esc(x.priority)} · ${esc(x.status || '')}</div>
      <div class="hint" style="white-space:pre-line">${esc(x.message || '')}</div>
    </div>`).join('') : '<div class="empty">No alerts yet.</div>';
};

// ---------- settings ----------
const getPath = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
const setPath = (o, p, v) => { const ks = p.split('.'); const last = ks.pop(); ks.reduce((a, k) => (a[k] ??= {}), o)[last] = v; };
let settings = null;
loaders.settings = async () => {
  settings = await api('/api/settings');
  $$('#settings-form [name]').forEach((el) => {
    const v = getPath(settings, el.name);
    if (el.type === 'checkbox') el.checked = !!v;
    else if (el.hasAttribute('data-feeds')) el.value = (v || []).map((f) => [f.name, f.url, f.store || '', f.everyMinutes || ''].join(' | ').replace(/( \| )+$/, '') + (f.enabled === false ? ' | off' : '')).join('\n');
    else el.value = el.hasAttribute('data-list') ? (v || []).join(', ') : v ?? '';
  });
};
$('#settings-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const next = structuredClone(settings);
  $$('#settings-form [name]').forEach((el) => {
    let v = el.type === 'checkbox' ? el.checked : el.value;
    if (el.hasAttribute('data-feeds')) {
      v = el.value.split('\n').map((l) => l.split('|').map((x) => x.trim())).filter((p) => p[0] && p[1])
        .map(([name, url, ...rest]) => {
          const st = rest.find((x) => ['homedepot', 'lowes', 'amazon', 'walmart'].includes(x));
          const mins = Number(rest.find((x) => /^\d+$/.test(x)));
          return { name, url, ...(st ? { store: st } : {}), ...(mins ? { everyMinutes: mins } : {}), enabled: !rest.includes('off') };
        });
    } else if (el.hasAttribute('data-list')) v = el.value.split(',').map((s) => s.trim()).filter(Boolean);
    else if (el.type === 'number') v = Number(el.value);
    if (el.tagName === 'SELECT') v = el.value;
    setPath(next, el.name, v);
  });
  settings = await api('/api/settings', { method: 'PUT', body: next });
  $('#settings-msg').textContent = 'Saved ✓'; setTimeout(() => ($('#settings-msg').textContent = ''), 2000);
  loadStatus();
});
$('#test-alert').addEventListener('click', async () => {
  const r = await api('/api/test-alert', { method: 'POST' });
  toast(r.status || 'sent');
});

// ---------- boot ----------
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
loadStatus(); setInterval(loadStatus, 60000);
window.addEventListener('hashchange', () => showTab(location.hash.slice(1)));
showTab((location.hash || '#hunt').slice(1));

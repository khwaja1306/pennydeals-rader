// Reddit penny-post watcher. Uses OAuth (app-only) if credentials are set,
// otherwise the public JSON listing, then the RSS feed as a last resort.
const cheerio = require('cheerio');
const { fetchText } = require('./http');

let tokenCache = { token: null, exp: 0 };

async function getToken(clientId, clientSecret) {
  if (tokenCache.token && Date.now() < tokenCache.exp - 60000) return tokenCache.token;
  const basic = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const txt = await fetchText('https://www.reddit.com/api/v1/access_token', {
    method: 'POST',
    body: 'grant_type=client_credentials',
    headers: { Authorization: `Basic ${basic}`, 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  const j = JSON.parse(txt);
  tokenCache = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return tokenCache.token;
}

function fromJson(txt, sub) {
  const j = JSON.parse(txt);
  return (j.data?.children || []).map(({ data: d }) => ({
    id: d.name || d.id,
    sub,
    title: d.title || '',
    body: d.selftext || '',
    author: d.author,
    url: d.permalink ? `https://www.reddit.com${d.permalink}` : d.url,
    created: new Date((d.created_utc || 0) * 1000).toISOString(),
    thumb: /^https?:/.test(d.thumbnail || '') ? d.thumbnail : null,
  }));
}

function fromRss(xml, sub) {
  const $ = cheerio.load(xml, { xmlMode: true });
  return $('entry').map((_, e) => {
    const $e = $(e);
    const content = cheerio.load($e.find('content').text() || '').text();
    return {
      id: $e.find('id').text(),
      sub,
      title: $e.find('title').text(),
      body: content,
      author: $e.find('author name').text().replace(/^\/u\//, ''),
      url: $e.find('link').attr('href'),
      created: $e.find('updated').text() || $e.find('published').text(),
      thumb: null,
    };
  }).get();
}

async function fetchSub(sub, cfg) {
  if (cfg.clientId && cfg.clientSecret) {
    const token = await getToken(cfg.clientId, cfg.clientSecret);
    const txt = await fetchText(`https://oauth.reddit.com/r/${sub}/new?limit=50&raw_json=1`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return fromJson(txt, sub);
  }
  try {
    return fromJson(await fetchText(`https://www.reddit.com/r/${sub}/new.json?limit=50&raw_json=1`), sub);
  } catch (e) {
    return fromRss(await fetchText(`https://www.reddit.com/r/${sub}/new/.rss?limit=50`), sub);
  }
}

function buildMatcher(keywords) {
  const esc = keywords.map((k) => k.trim()).filter(Boolean)
    .map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  // Word-ish boundaries that also work for "$0.01" and "1¢".
  return new RegExp(`(^|[^a-z0-9])(${esc.join('|')})(?=$|[^a-z0-9])`, 'i');
}

const SKU_RE = /\b(\d{4}-\d{3}-\d{3}|\d{3}-\d{3}|1\d{9}|\d{9})\b/g;

function extractSkus(text) {
  return [...new Set((text.match(SKU_RE) || []).map((s) => s.replace(/\D/g, '')))];
}

function classify(post, cfg) {
  const text = `${post.title}\n${post.body}`;
  const isPenny = buildMatcher(cfg.keywords).test(text);
  const isLocal = cfg.localKeywords?.length ? buildMatcher(cfg.localKeywords).test(text) : false;
  return { ...post, isPenny, isLocal, skus: extractSkus(text) };
}

async function fetchPennyPosts(cfg) {
  const out = [];
  const errors = [];
  for (const sub of cfg.subreddits) {
    try {
      const posts = await fetchSub(sub, cfg);
      for (const p of posts) out.push(classify(p, cfg));
    } catch (e) {
      errors.push(`r/${sub}: ${e.message}`);
    }
  }
  if (!out.length && errors.length) throw new Error(errors.join('; '));
  return { posts: out.filter((p) => p.isPenny), errors };
}

module.exports = { fetchPennyPosts, classify, extractSkus, buildMatcher, fromJson, fromRss };

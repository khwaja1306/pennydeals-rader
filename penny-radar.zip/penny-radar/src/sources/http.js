// Shared fetch with timeout and an honest User-Agent.
const UA = 'PennyRadar/1.0 (personal penny-alert app; low-frequency polling)';

async function fetchText(url, { headers = {}, timeoutMs = 20000, method = 'GET', body } = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method, body, headers: { 'User-Agent': UA, ...headers }, signal: ctrl.signal });
    const text = await res.text();
    if (!res.ok) {
      const err = new Error(`HTTP ${res.status} from ${new URL(url).host}`);
      err.status = res.status;
      throw err;
    }
    return text;
  } finally {
    clearTimeout(t);
  }
}

module.exports = { fetchText, UA };

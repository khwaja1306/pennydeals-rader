// Generic RSS / Atom feed source (Slickdeals, BudgetLightForum, or any feed you add).
// Each post is classified: which store it's about, whether it's a penny find,
// whether it's clearance, whether it mentions your area, and which SKUs it contains.
const cheerio = require('cheerio');
const { fetchText } = require('./http');
const { buildMatcher, extractSkus } = require('./reddit');

const HD_RE = /\b(home\s?depot|homedepot)\b/i;
// "HD" alone is ambiguous (HD TV, 1080p HD). Count it only in store context: "at HD", "@HD", "HD B&M", "HD clearance".
const HD_ABBR_RE = /(?:\b(?:at|from|my|local)\s+|@\s?)HD\b|\bHD\s+(?:B&M|clearance|penny|ymmv|store|app)\b|\bHD'?s\b/;
const LOWES_RE = /\blowe'?s\b|\blowes\.com\b/i;
const AMAZON_RE = /\b(amazon(?:\.com)?|amzn)\b/i;
const WALMART_RE = /\bwalmart\b/i;
// Words people use when a price is clearly wrong.
const GLITCH_RE = /\b(price (?:mistake|error|glitch)|pricing (?:error|mistake|glitch)|glitch(?:ed)?|mis-?priced|mispricing|price ?mistake|PM alert)\b/i;
const CLEARANCE_RE = /\b(clearance|ymmv|in[- ]store only|markdown|marked down|hidden deal|b&m)\b/i;
const ENDING_RE = /\$\s?\d+\.0[2346]\b/; // HD markdown endings like $5.03 / $12.06

function htmlToText(html) {
  if (!html) return '';
  return cheerio.load(`<div>${html}</div>`)('div').text().replace(/\s+/g, ' ').trim();
}

function parseFeed(xml, feedName) {
  const $ = cheerio.load(xml, { xmlMode: true });
  const out = [];
  $('item').each((_, el) => {
    const $e = $(el);
    out.push({
      id: $e.find('guid').first().text() || $e.find('link').first().text(),
      title: $e.find('title').first().text().trim(),
      body: htmlToText($e.find('content\\:encoded').first().text() || $e.find('description').first().text()),
      url: $e.find('link').first().text().trim(),
      author: $e.find('dc\\:creator').first().text() || $e.find('author').first().text(),
      created: new Date($e.find('pubDate').first().text() || Date.now()).toISOString(),
    });
  });
  $('entry').each((_, el) => {
    const $e = $(el);
    out.push({
      id: $e.find('id').first().text(),
      title: $e.find('title').first().text().trim(),
      body: htmlToText($e.find('content').first().text() || $e.find('summary').first().text()),
      url: $e.find('link').first().attr('href'),
      author: $e.find('author name').first().text(),
      created: new Date($e.find('updated').first().text() || $e.find('published').first().text() || Date.now()).toISOString(),
    });
  });
  return out.map((p) => ({ ...p, feed: feedName, id: `${feedName}:${p.id || p.url}` }));
}

// "$0.01", "$.01", "$1.24" — the first dollar amount in the title is usually the deal price.
function titlePrice(title) {
  const m = String(title).match(/\$\s?(\d{0,5}(?:,\d{3})*(?:\.\d{1,2})?)/);
  if (!m || m[1] === '') return null;
  const n = Number(m[1].replace(/,/g, ''));
  return Number.isFinite(n) ? n : null;
}

// Largest price in the text vs the deal price -> implied % off. "$106 ... list $799" -> 87.
function impliedDiscount(text, dealPrice) {
  if (dealPrice === null) return null;
  const prices = [...String(text).matchAll(/\$\s?(\d{1,6}(?:,\d{3})*(?:\.\d{1,2})?)/g)].map((m) => Number(m[1].replace(/,/g, ''))).filter((n) => n > 0);
  const max = Math.max(0, ...prices);
  if (!(max > dealPrice) || max < 20) return null;
  return Math.round((1 - dealPrice / max) * 100);
}

function extractAsin(text) {
  const m = String(text).match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})\b/) || String(text).match(/\bASIN:?\s*([A-Z0-9]{10})\b/);
  return m ? m[1] : null;
}

function classify(post, feed, cfg) {
  const text = `${post.title}\n${post.body}`;
  const head = `${post.title}\n${post.body.slice(0, 400)}`;
  const store = HD_RE.test(head) || HD_ABBR_RE.test(head) ? 'homedepot' : LOWES_RE.test(head) ? 'lowes'
    : AMAZON_RE.test(head) ? 'amazon' : WALMART_RE.test(head) ? 'walmart' : feed.store || null;
  const price = titlePrice(post.title);
  const isPenny = (price !== null && price <= 0.01) || buildMatcher(cfg.pennyKeywords).test(text);
  const isClearance = CLEARANCE_RE.test(text) || ENDING_RE.test(text);
  const discountPct = impliedDiscount(`${post.title} ${post.body.slice(0, 300)}`, price);
  const glitchWords = GLITCH_RE.test(text);
  // A glitch: someone calls it a price mistake, or the posted price is >= 85% below another price in the post,
  // or a normally-priced online store item shows for a penny.
  const isGlitch = glitchWords || (discountPct !== null && discountPct >= (cfg.glitchMinDiscount ?? 85))
    || (store === 'amazon' && price !== null && price <= 0.01);
  const isLocal = cfg.localKeywords?.length ? buildMatcher(cfg.localKeywords).test(text) : false;
  return { ...post, store, price, isPenny, isClearance, isGlitch, glitchWords, discountPct, isLocal, skus: extractSkus(text), asin: extractAsin(text) };
}

// Keep a post only if it's about Home Depot / Lowe's (unless the feed is store-specific)
// and it's a penny or clearance post.
function relevant(p, feed, cfg = {}) {
  if (p.isGlitch) {
    const stores = cfg.glitchStores || ['amazon'];
    if (stores.includes('any') || stores.includes(p.store) || (feed.store && stores.includes(feed.store))) return true;
  }
  if (p.store === 'amazon' || p.store === 'walmart') return false; // only glitches from online stores
  if (!p.store && feed.requireStore !== false) return false;
  return p.isPenny || p.isClearance || feed.keepAll === true;
}

async function fetchFeed(feed, cfg) {
  const xml = await fetchText(feed.url, { headers: { Accept: 'application/rss+xml, application/atom+xml, text/xml;q=0.9, */*;q=0.5' } });
  const posts = parseFeed(xml, feed.name);
  return posts.map((p) => classify(p, feed, cfg)).filter((p) => relevant(p, feed, cfg));
}

module.exports = { fetchFeed, parseFeed, classify, relevant, titlePrice, impliedDiscount, extractAsin };

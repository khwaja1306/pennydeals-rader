// PennyCentral live Penny List (community reports of Home Depot items scanning at $0.01).
// There is no public API, so we parse the page. The parser is deliberately tolerant:
//   1) product cards found via links to /sku/<digits>
//   2) fallback: SKU-like JSON embedded in Next.js script payloads
const cheerio = require('cheerio');
const { fetchText } = require('./http');

const BASE = 'https://www.pennycentral.com';

function normSku(s) { return String(s || '').replace(/\D/g, ''); }

function formatSku(digits) {
  // Display like HD store SKUs: 10-digit -> 1012-388-248, 6-digit -> 215-583
  if (digits.length === 10) return `${digits.slice(0, 4)}-${digits.slice(4, 7)}-${digits.slice(7)}`;
  if (digits.length === 6) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  return digits;
}

function cleanImg(src) {
  if (!src) return null;
  try {
    if (src.includes('/_next/image')) {
      const u = new URL(src, BASE);
      const inner = u.searchParams.get('url');
      if (inner) return new URL(inner, BASE).href;
    }
    return new URL(src, BASE).href;
  } catch { return null; }
}

function parseCardText(text) {
  const t = text.replace(/\s+/g, ' ').trim();
  const num = (re) => { const m = t.match(re); return m ? Number(m[1]) : null; };
  const lastSeen = (t.match(/Last seen:?\s*(Today|Yesterday|\d+\s+\w+\s+ago|[A-Z][a-z]{2,8}\.? \d{1,2}(?:, \d{4})?)/i) || [])[1] || null;
  return {
    states: num(/(\d+)\s+states?\b/i),
    reports: num(/(\d+)\s+reports?\b/i),
    lastSeen,
  };
}

// Text of an element with a space between every text node, so "14 states" and
// "23 reports" in sibling elements don't run together as "14 states23 reports".
function spacedText($, el) {
  const out = [];
  const walk = (n) => {
    if (n.type === 'text') out.push(n.data);
    else if (n.children && !['script', 'style'].includes(n.name)) n.children.forEach(walk);
  };
  $(el).each((_, n) => walk(n));
  return out.join(' ').replace(/\s+/g, ' ').trim();
}

function parseHtml(html) {
  const $ = cheerio.load(html);
  const items = new Map();

  $('a[href*="/sku/"]').each((_, a) => {
    const href = $(a).attr('href') || '';
    const m = href.match(/\/sku\/([\d-]+)/);
    if (!m) return;
    const sku = normSku(m[1]);
    if (sku.length < 6) return;

    // Climb to the smallest ancestor that looks like a whole card.
    let card = $(a);
    for (let i = 0; i < 6; i++) {
      const txt = spacedText($, card);
      if (/states?\b/i.test(txt) && (card.find('img').length || /SKU/i.test(txt))) break;
      if (!card.parent().length) break;
      card = card.parent();
    }
    // Don't let a card swallow several products.
    if (card.find('a[href*="/sku/"]').map((__, x) => normSku(($(x).attr('href') || '').split('/sku/')[1])).get()
      .filter((v, i, arr) => arr.indexOf(v) === i).length > 1) card = $(a).parent();

    const text = spacedText($, card);
    const img = card.find('img').first();
    const name = (img.attr('alt') || card.find('h2,h3,h4').first().text() || $(a).text() || '').replace(/\s+/g, ' ').trim();
    const prev = items.get(sku) || {};
    const parsed = parseCardText(text);
    items.set(sku, {
      sku,
      skuDisplay: formatSku(sku),
      name: (name.length > (prev.name || '').length ? name : prev.name) || `SKU ${formatSku(sku)}`,
      states: parsed.states ?? prev.states ?? null,
      reports: parsed.reports ?? prev.reports ?? null,
      lastSeen: parsed.lastSeen ?? prev.lastSeen ?? null,
      image: cleanImg(img.attr('src')) || prev.image || null,
      url: `${BASE}/sku/${sku}`,
    });
  });

  if (items.size === 0) {
    // Fallback: Next.js flight data / embedded JSON.
    const raw = html.replace(/\\"/g, '"');
    const re = /"sku"\s*:\s*"?([\d-]{6,14})"?/g;
    let m;
    while ((m = re.exec(raw))) {
      const sku = normSku(m[1]);
      if (items.has(sku)) continue;
      const window = raw.slice(Math.max(0, m.index - 600), m.index + 600);
      const name = (window.match(/"(?:name|title|productName)"\s*:\s*"([^"]{4,200})"/) || [])[1];
      const states = (window.match(/"(?:stateCount|states_count|statesCount)"\s*:\s*(\d+)/) || [])[1];
      const reports = (window.match(/"(?:reportCount|reports|report_count)"\s*:\s*(\d+)/) || [])[1];
      items.set(sku, {
        sku, skuDisplay: formatSku(sku), name: name || `SKU ${formatSku(sku)}`,
        states: states ? Number(states) : null, reports: reports ? Number(reports) : null,
        lastSeen: null, image: null, url: `${BASE}/sku/${sku}`,
      });
    }
  }
  return [...items.values()];
}

async function fetchList(url = `${BASE}/penny-list`) {
  const html = await fetchText(url, { headers: { Accept: 'text/html' } });
  const items = parseHtml(html);
  if (!items.length) throw new Error('PennyCentral page loaded but no items were recognised — the page layout may have changed');
  return items;
}

module.exports = { fetchList, parseHtml, formatSku, normSku };

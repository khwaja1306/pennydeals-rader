// Polling jobs: PennyCentral list, Reddit posts, watchlist scoring. Each one diffs
// against what it saw last time and only alerts on genuine changes.
const store = require('./store');
const config = require('./config');
const notify = require('./notify');
const watchlist = require('./watchlist');
const pennycentral = require('./sources/pennycentral');
const reddit = require('./sources/reddit');
const feeds = require('./sources/feeds');
const { buildMatcher } = require('./sources/reddit');

const status = { pennycentral: {}, reddit: {}, feeds: {}, watchlist: {} };

function keywordHit(text) {
  const kws = config.get().keywords || [];
  if (!kws.length) return null;
  const m = String(text).match(buildMatcher(kws));
  return m ? m[2] : null;
}

function watchedSkus() {
  const map = new Map();
  for (const i of store.get().watchlist) if (i.sku) map.set(pennycentral.normSku(i.sku), i);
  return map;
}

async function runPennyCentral({ silent = false } = {}) {
  const cfg = config.get().sources.pennycentral;
  const db = store.get();
  const st = (status.pennycentral = { running: true, at: new Date().toISOString() });
  try {
    const items = await pennycentral.fetchList(cfg.url);
    const firstRun = !db.pc.seeded;
    const watched = watchedSkus();
    const now = new Date().toISOString();
    let fresh = 0;
    for (const it of items) {
      const prev = db.pc.items[it.sku];
      const rec = { ...prev, ...it, firstSeen: prev?.firstSeen || now, lastFetched: now, alertedStates: prev?.alertedStates ?? 0 };
      const hist = prev?.history || [];
      if (!hist.length || hist[hist.length - 1].states !== it.states) hist.push({ at: now, states: it.states, reports: it.reports });
      rec.history = hist.slice(-30);
      db.pc.items[it.sku] = rec;
      if (firstRun || silent) { rec.alertedStates = it.states || 0; continue; }

      const w = watched.get(it.sku);
      const kw = keywordHit(it.name);
      if (!prev) fresh++;
      if (w) {
        await notify.alert({ key: `pc-watch-${it.sku}`, kind: 'watch-hit', priority: 'urgent', tags: ['rotating_light'],
          title: `🎯 Watchlist item is PENNY somewhere: ${w.name}`,
          message: `PennyCentral: ${it.states ?? '?'} state(s), ${it.reports ?? '?'} report(s). SKU ${it.skuDisplay}. Check your store${w.storeName ? ` (${w.storeName})` : ''}.`,
          url: it.url, image: it.image });
      } else if (!prev && (kw || (it.states || 0) >= cfg.pushNewIfStatesAtLeast)) {
        await notify.alert({ key: `pc-new-${it.sku}`, kind: 'pc-new', priority: kw ? 'high' : 'normal', tags: ['coin'],
          title: `New penny: ${it.name}`,
          message: `${it.states ?? '?'} state(s) · SKU ${it.skuDisplay}${kw ? ` · matches "${kw}"` : ''}`,
          url: it.url, image: it.image });
        rec.alertedStates = it.states || 0;
      } else if (prev && it.states && it.states - (rec.alertedStates || 0) >= cfg.spreadDelta) {
        await notify.alert({ key: `pc-spread-${it.sku}-${it.states}`, kind: 'pc-spread', priority: kw ? 'high' : 'normal', tags: ['chart_with_upwards_trend'],
          title: `Spreading: ${it.name}`,
          message: `Now reported in ${it.states} states (was ${rec.alertedStates || prev.states}). SKU ${it.skuDisplay}`,
          url: it.url, image: it.image });
        rec.alertedStates = it.states;
      }
    }
    // Remember items that dropped off the list (they stay searchable, flagged as off-list).
    const current = new Set(items.map((i) => i.sku));
    for (const [sku, rec] of Object.entries(db.pc.items)) rec.onList = current.has(sku);

    db.pc.seeded = true;
    db.pc.lastFetch = now;
    db.pc.lastError = null;
    Object.assign(st, { ok: true, count: items.length, fresh, firstRun });
  } catch (e) {
    db.pc.lastError = { at: new Date().toISOString(), message: e.message };
    Object.assign(st, { ok: false, error: e.message });
  } finally {
    st.running = false;
    store.save();
  }
  return st;
}

async function runReddit({ silent = false } = {}) {
  const cfg = config.get().sources.reddit;
  const db = store.get();
  const st = (status.reddit = { running: true, at: new Date().toISOString() });
  try {
    const { posts, errors } = await reddit.fetchPennyPosts(cfg);
    const firstRun = !db.reddit.seeded;
    const watched = watchedSkus();
    let fresh = 0;
    for (const p of posts) {
      if (db.reddit.seen[p.id]) continue;
      db.reddit.seen[p.id] = Date.now();
      db.reddit.posts.unshift(p);
      fresh++;
      if (firstRun || silent) continue;
      const hitSku = (p.skus || []).find((s) => watched.has(s));
      const kw = keywordHit(`${p.title} ${p.body}`);
      await notify.alert({
        key: `rd-${p.id}`, kind: 'reddit',
        priority: hitSku ? 'urgent' : p.isLocal ? 'high' : kw ? 'normal' : 'low',
        tags: ['speech_balloon'],
        title: `${hitSku ? '🎯 ' : ''}r/${p.sub}: ${p.title}`.slice(0, 150),
        message: [p.isLocal ? '📍 Mentions your area.' : '', p.skus?.length ? `SKUs: ${p.skus.join(', ')}` : '', p.body.slice(0, 200)].filter(Boolean).join('\n'),
        url: p.url,
      });
    }
    db.reddit.posts = db.reddit.posts.slice(0, 300);
    // Prune the seen-set after 30 days.
    const cutoff = Date.now() - 30 * 86400000;
    for (const [k, t] of Object.entries(db.reddit.seen)) if (t < cutoff) delete db.reddit.seen[k];
    db.reddit.seeded = true;
    db.reddit.lastFetch = new Date().toISOString();
    db.reddit.lastError = errors.length ? { at: new Date().toISOString(), message: errors.join('; ') } : null;
    Object.assign(st, { ok: true, fresh, firstRun, warnings: errors });
  } catch (e) {
    db.reddit.lastError = { at: new Date().toISOString(), message: e.message };
    Object.assign(st, { ok: false, error: e.message });
  } finally {
    st.running = false;
    store.save();
  }
  return st;
}

// onlyDue: the scheduler passes true so each feed runs on its own interval (feed.everyMinutes);
// "Fetch now" runs every feed.
async function runFeeds({ silent = false, onlyDue = false, now = Date.now() } = {}) {
  const all = config.get();
  const cfg = all.sources.feeds;
  const g = cfg.glitch || {};
  const classifyCfg = {
    pennyKeywords: cfg.pennyKeywords, localKeywords: all.sources.reddit.localKeywords,
    glitchStores: g.enabled === false ? [] : g.stores, glitchMinDiscount: g.minDiscount,
  };
  const db = store.get();
  db.feeds = db.feeds || { seen: {}, posts: [], seeded: {}, perFeed: {} };
  db.feeds.perFeed = db.feeds.perFeed || {};
  const st = (status.feeds = { running: true, at: new Date().toISOString(), perFeed: {} });
  const watched = watchedSkus();
  const errors = [];
  let fresh = 0;
  for (const feed of (cfg.list || []).filter((f) => f.enabled !== false && f.url)) {
    if (onlyDue) {
      const last = db.feeds.perFeed[feed.name]?.at;
      const every = (feed.everyMinutes || cfg.intervalMinutes) * 60000;
      if (last && now - new Date(last).getTime() < every - 5000) continue;
    }
    try {
      const posts = await feeds.fetchFeed(feed, classifyCfg);
      const firstRun = !db.feeds.seeded[feed.name];
      let n = 0;
      for (const p of posts) {
        if (db.feeds.seen[p.id]) continue;
        db.feeds.seen[p.id] = Date.now();
        db.feeds.posts.unshift(p);
        n++;
        if (firstRun || silent) continue;
        const hitSku = (p.skus || []).find((s) => watched.has(s));
        const kw = keywordHit(`${p.title} ${p.body}`);
        if (p.isGlitch && g.enabled !== false) {
          const storeName = { amazon: 'Amazon', walmart: 'Walmart', homedepot: 'Home Depot', lowes: "Lowe's" }[p.store] || 'Online';
          await notify.alert({
            key: `fd-${p.id}`, kind: 'glitch', priority: g.priority || 'urgent', tags: ['zap'],
            title: `⚡ ${storeName} glitch: ${p.title}`.slice(0, 150),
            message: [`via ${p.feed}`, p.discountPct ? `~${p.discountPct}% below the other price in the post` : '', p.glitchWords ? 'Posted as a price mistake' : '',
              'Glitches usually last minutes and may be cancelled — check before buying.', p.body.slice(0, 160)].filter(Boolean).join('\n'),
            url: p.url,
          });
          continue;
        }
        let priority = null;
        if (hitSku) priority = 'urgent';
        else if (p.isPenny) priority = p.isLocal ? 'urgent' : 'high';
        else if (p.isClearance && (kw || cfg.pushClearance)) priority = p.isLocal ? 'high' : 'normal';
        if (!priority) continue;
        const storeTag = p.store === 'lowes' ? "Lowe's" : p.store === 'homedepot' ? 'HD' : '';
        await notify.alert({
          key: `fd-${p.id}`, kind: 'feed', priority, tags: [p.isPenny ? 'coin' : 'label'],
          title: `${hitSku ? '🎯 ' : ''}${p.isPenny ? 'Penny' : 'Clearance'}${storeTag ? ` (${storeTag})` : ''}: ${p.title}`.slice(0, 150),
          message: [`via ${p.feed}`, p.isLocal ? '📍 Mentions your area.' : '', kw ? `Matches "${kw}"` : '', p.skus?.length ? `SKUs: ${p.skus.join(', ')}` : '', p.body.slice(0, 200)].filter(Boolean).join('\n'),
          url: p.url,
        });
      }
      db.feeds.seeded[feed.name] = true;
      db.feeds.perFeed[feed.name] = { ok: true, at: new Date().toISOString(), fresh: n };
      st.perFeed[feed.name] = { ok: true, fresh: n, firstRun };
      fresh += n;
    } catch (e) {
      errors.push(`${feed.name}: ${e.message}`);
      db.feeds.perFeed[feed.name] = { ok: false, at: new Date().toISOString(), error: e.message };
      st.perFeed[feed.name] = { ok: false, error: e.message };
    }
  }
  db.feeds.posts = db.feeds.posts.slice(0, 400);
  const cutoff = Date.now() - 45 * 86400000;
  for (const [k, t] of Object.entries(db.feeds.seen)) if (t < cutoff) delete db.feeds.seen[k];
  db.feeds.lastFetch = new Date().toISOString();
  db.feeds.lastError = errors.length ? { at: db.feeds.lastFetch, message: errors.join('; ') } : null;
  Object.assign(st, { running: false, ok: errors.length === 0, fresh, errors });
  store.save();
  return st;
}

async function runWatchlist(now = new Date()) {
  const cfg = config.get().sources.watchlist;
  const st = (status.watchlist = { at: now.toISOString() });
  const items = store.get().watchlist.filter((i) => !i.archived).map((i) => watchlist.evaluate(i, now));
  let alerts = 0;
  for (const it of items) {
    const where = it.storeName ? ` @ ${it.storeName}` : '';
    if (it.decoded?.stage === 'final') {
      const r = await notify.alert({ key: `wl-final-${it.id}-${it.latest?.id}`, kind: 'watch', priority: 'high', tags: ['hourglass'],
        title: `Final markdown: ${it.name}${where}`,
        message: `${it.decoded.label}. ${it.prediction ? `Penny window from ${fmt(it.prediction.pennyFrom)}.` : ''}`,
        url: it.links.store });
      if (!r.skipped) alerts++;
    }
    if (it.prediction?.pennyFrom && now >= new Date(it.prediction.pennyFrom) && now <= new Date(it.prediction.pennyTo)) {
      const r = await notify.alert({ key: `wl-window-${it.id}-${it.latest?.id}`, kind: 'watch', priority: 'urgent', tags: ['moneybag'],
        title: `Go check now: ${it.name}${where}`,
        message: `Predicted penny window is open (${fmt(it.prediction.pennyFrom)} – ${fmt(it.prediction.pennyTo)}). Score ${it.score}.`,
        url: it.links.store });
      if (!r.skipped) alerts++;
    }
    if (it.score >= cfg.pushScoreAtLeast) {
      const bucket = Math.floor(it.score / 10) * 10;
      const r = await notify.alert({ key: `wl-score-${it.id}-${bucket}`, kind: 'watch', priority: it.score >= 85 ? 'urgent' : 'high', tags: ['dart'],
        title: `Penny score ${it.score}: ${it.name}${where}`,
        message: it.reasons.join('\n'), url: it.links.store });
      if (!r.skipped) alerts++;
    }
  }
  Object.assign(st, { ok: true, checked: items.length, alerts });
  return st;
}

function fmt(d) { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); }

// Scheduler: a 1-minute tick that runs each job when its interval has elapsed.
const lastRun = { pennycentral: 0, reddit: 0, feeds: 0, watchlist: 0 };
let ticking = false;

async function tick(now = Date.now()) {
  if (ticking) return;
  ticking = true;
  try {
    const s = config.get().sources;
    if (s.pennycentral.enabled && now - lastRun.pennycentral >= s.pennycentral.intervalMinutes * 60000) {
      lastRun.pennycentral = now; await runPennyCentral();
    }
    if (s.reddit.enabled && now - lastRun.reddit >= s.reddit.intervalMinutes * 60000) {
      lastRun.reddit = now; await runReddit();
    }
    if (s.feeds?.enabled && now - lastRun.feeds >= 60000) { // each feed has its own interval
      lastRun.feeds = now; await runFeeds({ onlyDue: true, now });
    }
    if (now - lastRun.watchlist >= s.watchlist.intervalMinutes * 60000) {
      lastRun.watchlist = now; await runWatchlist(new Date(now));
    }
    await notify.maintenance(new Date(now));
  } catch (e) {
    console.error('tick error', e);
  } finally {
    ticking = false;
  }
}

function start() {
  tick();
  return setInterval(tick, 60000);
}

module.exports = { start, tick, runPennyCentral, runReddit, runFeeds, runWatchlist, status };

// Watchlist: items you're tracking at specific stores, with price observations
// you log from shelf tags or the HD app. Produces a penny score + predicted window.
const store = require('./store');
const { decodeHD, decodeLowes, predict, score } = require('./engine/cadence');
const { normSku } = require('./sources/pennycentral');

function newId() { return Math.random().toString(36).slice(2, 10); }

function latestObs(item) {
  return [...(item.observations || [])].sort((a, b) => new Date(b.date) - new Date(a.date))[0] || null;
}

function evaluate(item, now = new Date()) {
  const db = store.get();
  const obs = latestObs(item);
  const sku = normSku(item.sku);
  const pc = sku ? db.pc.items[sku] : null;
  const redditMentions = sku ? [...db.reddit.posts, ...(db.feeds?.posts || [])].filter((p) => p.isPenny && (p.skus || []).includes(sku)).length : 0;

  let decoded = null, prediction = null;
  if (obs) {
    decoded = item.store === 'lowes'
      ? decodeLowes(obs.price, item.originalPrice)
      : decodeHD(obs.price, { clearance: obs.clearance !== false });
    // Tag date = the date printed on the clearance tag; fall back to when you saw it.
    if (item.store !== 'lowes') prediction = predict(decoded, obs.tagDate || obs.date);
  }
  const s = score({
    decoded, prediction, now,
    pcStates: pc ? (pc.states || 1) : 0,
    redditMentions,
    appNotFound: obs?.appNotFound,
    onlineUnavailable: obs?.onlineUnavailable,
    store: item.store,
  });
  return {
    ...item,
    latest: obs,
    decoded,
    prediction,
    score: s.score,
    reasons: s.reasons,
    onPennyCentral: !!pc,
    pc: pc ? { states: pc.states, reports: pc.reports, url: pc.url, lastSeen: pc.lastSeen } : null,
    redditMentions,
    links: links(item),
  };
}

function links(item) {
  const sku = normSku(item.sku);
  const q = encodeURIComponent(sku || item.name || '');
  return item.store === 'lowes'
    ? { store: `https://www.lowes.com/search?searchTerm=${q}`, brickseek: 'https://brickseek.com/' }
    : {
      store: `https://www.homedepot.com/s/${q}`,
      pennycentral: sku ? `https://www.pennycentral.com/sku/${sku}` : null,
      scavenger: 'https://scavenger.ai',
    };
}

function list() { return store.get().watchlist.map((i) => evaluate(i)).sort((a, b) => b.score - a.score); }

function topHunt(n = 10) { return list().filter((i) => i.score >= 40 && !i.archived).slice(0, n); }

function add({ store: st = 'homedepot', sku = '', name = '', storeName = '', originalPrice = null, notes = '' }) {
  const item = { id: newId(), store: st, sku: String(sku).trim(), name: name.trim() || `SKU ${sku}`, storeName, originalPrice: originalPrice ? Number(originalPrice) : null, notes, created: new Date().toISOString(), observations: [] };
  store.get().watchlist.push(item);
  store.save();
  return evaluate(item);
}

function update(id, patch) {
  const item = store.get().watchlist.find((i) => i.id === id);
  if (!item) return null;
  for (const k of ['name', 'sku', 'storeName', 'originalPrice', 'notes', 'archived', 'store']) if (k in patch) item[k] = patch[k];
  store.save();
  return evaluate(item);
}

function remove(id) {
  const db = store.get();
  db.watchlist = db.watchlist.filter((i) => i.id !== id);
  store.save();
}

function addObservation(id, { price, date, tagDate, clearance = true, appNotFound = false, onlineUnavailable = false, note = '' }) {
  const item = store.get().watchlist.find((i) => i.id === id);
  if (!item) return null;
  item.observations.push({
    id: newId(), price: Number(price), date: date || new Date().toISOString().slice(0, 10),
    tagDate: tagDate || null, clearance: !!clearance, appNotFound: !!appNotFound, onlineUnavailable: !!onlineUnavailable, note,
  });
  store.save();
  return evaluate(item);
}

module.exports = { list, add, update, remove, addObservation, evaluate, topHunt, links };

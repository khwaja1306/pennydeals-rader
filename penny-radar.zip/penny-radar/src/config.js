// Settings live in data/settings.json and are editable from the dashboard.
const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

const DEFAULTS = {
  home: { zip: '43035', label: 'Lewis Center, OH', state: 'OH' },
  sources: {
    pennycentral: {
      enabled: true,
      url: 'https://www.pennycentral.com/penny-list',
      intervalMinutes: 60,          // be polite: once an hour is plenty
      pushNewIfStatesAtLeast: 5,    // push a new list item when seen in >= N states
      spreadDelta: 3,               // push when an item gains >= N states since last alert
    },
    reddit: {
      enabled: true,
      subreddits: ['HomeDepot', 'Lowes'],
      intervalMinutes: 30,
      clientId: '',                 // optional: Reddit "script/installed app" creds for reliable access
      clientSecret: '',
      keywords: ['penny', 'pennies', '$0.01', '$.01', '1 cent', 'one cent', '1¢'],
      localKeywords: ['ohio', 'columbus', 'lewis center', 'delaware', 'polaris', 'westerville'],
    },
    feeds: {
      enabled: true,
      intervalMinutes: 30,
      pushClearance: false,         // push clearance (non-penny) posts only when they match a keyword
      glitch: {
        enabled: true,
        stores: ['amazon'],         // add 'walmart', 'homedepot', 'lowes' or 'any' to widen
        minDiscount: 85,            // % below the highest price in the post that counts as a glitch
        priority: 'urgent',         // glitches die in minutes; urgent ignores quiet hours
      },
      pennyKeywords: ['penny', 'pennies', '$0.01', '$.01', '1 cent', 'one cent', '1¢', 'penny item'],
      list: [
        { name: 'Slickdeals Hot Deals', url: 'https://slickdeals.net/newsearch.php?searchin=first&forumchoice%5B%5D=9&rss=1', everyMinutes: 10, enabled: true },
        { name: 'Slickdeals Frontpage', url: 'https://slickdeals.net/newsearch.php?mode=frontpage&searcharea=deals&searchin=first&rss=1', enabled: true },
        { name: 'Slickdeals price mistakes', url: 'https://slickdeals.net/newsearch.php?searchin=first&rss=1&sort=newest&q=price+mistake', everyMinutes: 5, enabled: true },
        { name: 'BudgetLightForum HD thread', url: 'https://budgetlightforum.com/t/home-depot-deal-alerts-discussion-thread/27168.rss', store: 'homedepot', enabled: true },
      ],
    },
    watchlist: { intervalMinutes: 60, pushScoreAtLeast: 70 },
  },
  keywords: ['milwaukee', 'dewalt', 'ryobi', 'makita', 'husky', 'cooler', 'generator', 'vanity', 'faucet'],
  notify: {
    ntfy: { enabled: false, server: 'https://ntfy.sh', topic: '', token: '' },
    telegram: { enabled: false, botToken: '', chatId: '' },
    quietHours: { enabled: true, start: '22:00', end: '07:00' }, // only urgent alerts during quiet hours
    dailyDigest: { enabled: true, time: '07:30' },
  },
  publicUrl: '', // e.g. http://192.168.1.20:8787 — used for "open dashboard" links in alerts
};

function deepMerge(base, over) {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over || {})) out[k] = k in base ? deepMerge(base[k], over[k]) : over[k];
  return out;
}

let current = null;

function load() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  let saved = {};
  try { saved = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch { /* first run */ }
  current = deepMerge(DEFAULTS, saved);
  if (migrateFeeds(current, saved)) save(current);
  return current;
}

// New built-in feeds are added to an existing install exactly once, so updates bring
// new sources without resurrecting feeds the user deleted.
function migrateFeeds(cfg, saved) {
  const f = cfg.sources.feeds;
  if (!saved?.sources?.feeds?.list) { f.seenDefaults = DEFAULTS.sources.feeds.list.map((d) => d.name); return false; }
  const seen = new Set(f.seenDefaults || ['Slickdeals Hot Deals', 'Slickdeals Frontpage', 'BudgetLightForum HD thread']);
  let changed = !f.seenDefaults;
  for (const d of DEFAULTS.sources.feeds.list) {
    if (seen.has(d.name)) continue;
    if (!f.list.some((x) => x.name === d.name || x.url === d.url)) f.list.push({ ...d });
    seen.add(d.name);
    changed = true;
  }
  f.seenDefaults = [...seen];
  return changed;
}

function get() { return current || load(); }

function save(next) {
  current = deepMerge(DEFAULTS, next);
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(SETTINGS_FILE + '.tmp', JSON.stringify(current, null, 2));
  fs.renameSync(SETTINGS_FILE + '.tmp', SETTINGS_FILE);
  return current;
}

module.exports = { get, save, load, DEFAULTS, DATA_DIR, deepMerge };

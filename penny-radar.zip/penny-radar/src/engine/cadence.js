// Clearance-tag decoding, penny-date prediction and penny-likelihood scoring.
//
// Home Depot cadences are community-observed, not official (see PennyCentral's guide):
//   Cadence A (~13 wks): .00 (~4 wks) -> .06 (~6 wks) -> .03 (~3 wks) -> $0.01
//   Cadence B (~7 wks):  .00 (1-2 wks) -> .04 (~4 wks) -> .02 (~2 wks) -> $0.01
// Treat every date this produces as a planning window, never a guarantee.

const DAY = 86400000;

const HD_ENDINGS = {
  0:  { stage: 'initial', cadence: null, weeks: 3, label: 'Initial clearance (.00)' },
  6:  { stage: 'second',  cadence: 'A',  weeks: 6, label: 'Mid-clearance, cadence A (.06)' },
  4:  { stage: 'second',  cadence: 'B',  weeks: 4, label: 'Mid-clearance, cadence B (.04)' },
  3:  { stage: 'final',   cadence: 'A',  weeks: 3, label: 'Final markdown, cadence A (.03)' },
  2:  { stage: 'final',   cadence: 'B',  weeks: 2, label: 'Final markdown, cadence B (.02)' },
  1:  { stage: 'final',   cadence: null, weeks: 2, label: 'Final markdown (.01 ending)' },
};
const FINAL_WEEKS = { A: 3, B: 2 };

const STAGE_BASE = { penny: 100, final: 60, second: 30, initial: 12, other: 5, regular: 0 };

function centsOf(price) { return Math.round(Number(price) * 100) % 100; }

function decodeHD(price, { clearance = true } = {}) {
  const p = Number(price);
  if (!(p >= 0)) return { stage: 'unknown', label: 'Enter a price' };
  if (p <= 0.01) return { stage: 'penny', cadence: null, weeks: 0, label: 'PENNY ($0.01)' };
  const c = centsOf(p);
  if ([97, 98, 99].includes(c) && !clearance) return { stage: 'regular', label: 'Regular / sale price' };
  if (c === 97) return { stage: 'regular', label: '.97 is usually a regular sale price, not clearance' };
  const hit = HD_ENDINGS[c];
  if (hit) {
    if (c === 0 && !clearance) return { stage: 'regular', label: 'Round price without a clearance tag' };
    return { ...hit };
  }
  return { stage: 'other', label: `Ending .${String(c).padStart(2, '0')} has no reliable meaning` };
}

// Lowe's rarely lets items reach a penny; we score depth of discount instead.
function decodeLowes(price, original) {
  const p = Number(price), o = Number(original);
  if (!(p >= 0)) return { stage: 'unknown', label: 'Enter a price' };
  if (p <= 0.01) return { stage: 'penny', label: 'PENNY ($0.01) — rare at Lowe\'s' };
  if (!(o > 0)) return { stage: 'other', label: 'Add the original price to score the discount' };
  const off = Math.round((1 - p / o) * 100);
  const stage = off >= 75 ? 'final' : off >= 50 ? 'second' : off >= 20 ? 'initial' : 'regular';
  return { stage, discountPct: off, label: `${off}% off original` };
}

function addDays(date, days) { return new Date(new Date(date).getTime() + days * DAY); }

// Predict next markdown and penny window from a decoded tag + tag date.
function predict(decoded, tagDate) {
  if (!tagDate || !decoded || !decoded.stage) return null;
  // Date-only strings ("2026-11-01") are read as local noon so they don't shift a day across time zones.
  const start = /^\d{4}-\d{2}-\d{2}$/.test(String(tagDate)) ? new Date(`${tagDate}T12:00:00`) : new Date(tagDate);
  if (isNaN(start)) return null;
  const { stage, cadence, weeks } = decoded;
  if (stage === 'final') {
    return { nextMarkdown: null, pennyFrom: addDays(start, weeks * 7), pennyTo: addDays(start, weeks * 7 + 21) };
  }
  if (stage === 'second') {
    const next = addDays(start, weeks * 7);
    const fw = FINAL_WEEKS[cadence] || 3;
    return { nextMarkdown: next, pennyFrom: addDays(next, fw * 7), pennyTo: addDays(next, fw * 7 + 21) };
  }
  if (stage === 'initial') {
    // Cadence unknown at this point: span B (fast) to A (slow).
    return { nextMarkdown: addDays(start, 14), pennyFrom: addDays(start, 7 * 7), pennyTo: addDays(start, 13 * 7 + 21) };
  }
  return null;
}

/**
 * Score 0-100 for how likely an item is to scan at $0.01 now.
 * signals: { decoded, prediction, now, pcStates, pcReports, appNotFound, onlineUnavailable, redditMentions, store }
 */
function score(s) {
  const now = s.now ? new Date(s.now) : new Date();
  const reasons = [];
  let v = STAGE_BASE[s.decoded?.stage] ?? 0;
  if (s.decoded?.stage) reasons.push(`${s.decoded.label} (+${v})`);
  if (s.decoded?.stage === 'penny') return { score: 100, reasons };

  const pr = s.prediction;
  if (pr?.pennyFrom) {
    const days = (new Date(pr.pennyFrom) - now) / DAY;
    if (days <= 0 && now <= new Date(pr.pennyTo)) { v += 20; reasons.push('Inside predicted penny window (+20)'); }
    else if (days <= 0) { v += 8; reasons.push('Past penny window — may already be pulled (+8)'); }
    else if (days <= 7) { v += 10; reasons.push(`Penny window opens in ${Math.ceil(days)}d (+10)`); }
  }
  if (s.pcStates > 0) {
    const add = 25 + Math.min(10, s.pcStates);
    v += add; reasons.push(`On PennyCentral list in ${s.pcStates} state(s) (+${add})`);
  }
  if (s.redditMentions > 0) { v += 8; reasons.push('Reported as penny on a forum / Reddit (+8)'); }
  if (s.appNotFound) { v += 15; reasons.push('HD app shows "not found"/no price while on shelf (+15)'); }
  if (s.onlineUnavailable) { v += 5; reasons.push('Unavailable online (+5)'); }
  if (s.store === 'lowes') { v = Math.round(v * 0.6); reasons.push('Lowe\'s rarely sells pennies (×0.6)'); }
  return { score: Math.max(0, Math.min(99, Math.round(v))), reasons };
}

module.exports = { decodeHD, decodeLowes, predict, score, centsOf, DAY };

// Push alerts via ntfy (free phone app, no account) and/or Telegram.
// Every alert is logged; quiet hours hold non-urgent alerts for the morning digest.
const store = require('./store');
const config = require('./config');
const { fetchText } = require('./sources/http');

const PRIORITY = { urgent: 5, high: 4, normal: 3, low: 2 };

function minutes(hhmm) { const [h, m] = String(hhmm).split(':').map(Number); return h * 60 + (m || 0); }

function inQuietHours(qh, now = new Date()) {
  if (!qh?.enabled) return false;
  const cur = now.getHours() * 60 + now.getMinutes();
  const s = minutes(qh.start), e = minutes(qh.end);
  return s <= e ? cur >= s && cur < e : cur >= s || cur < e;
}

async function sendNtfy(cfg, a) {
  const server = (cfg.server || 'https://ntfy.sh').replace(/\/$/, '');
  const body = {
    topic: cfg.topic,
    title: a.title,
    message: a.message,
    priority: PRIORITY[a.priority] || 3,
    tags: a.tags || [],
    ...(a.url ? { click: a.url } : {}),
    ...(a.image ? { attach: a.image } : {}),
  };
  const headers = { 'Content-Type': 'application/json' };
  if (cfg.token) headers.Authorization = `Bearer ${cfg.token}`;
  await fetchText(server, { method: 'POST', body: JSON.stringify(body), headers });
}

function escHtml(s) { return String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }

async function sendTelegram(cfg, a) {
  const text = `<b>${escHtml(a.title)}</b>\n${escHtml(a.message)}${a.url ? `\n${escHtml(a.url)}` : ''}`;
  await fetchText(`https://api.telegram.org/bot${cfg.botToken}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: cfg.chatId, text, parse_mode: 'HTML', disable_notification: a.priority === 'low' }),
  });
}

async function deliver(a) {
  const n = config.get().notify;
  const errors = [];
  let sent = 0;
  if (n.ntfy.enabled && n.ntfy.topic) {
    try { await sendNtfy(n.ntfy, a); sent++; } catch (e) { errors.push(`ntfy: ${e.message}`); }
  }
  if (n.telegram.enabled && n.telegram.botToken && n.telegram.chatId) {
    try { await sendTelegram(n.telegram, a); sent++; } catch (e) { errors.push(`telegram: ${e.message}`); }
  }
  return { sent, errors };
}

/**
 * alert({ key, title, message, priority, url, image, tags, kind })
 * key: dedupe key — the same key is never pushed twice.
 */
async function alert(a, { force = false } = {}) {
  const db = store.get();
  if (a.key && db.sent[a.key] && !force) return { skipped: 'duplicate' };
  const entry = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, at: new Date().toISOString(), priority: 'normal', ...a };
  if (a.key) db.sent[a.key] = entry.at;

  const cfg = config.get();
  if (!force && entry.priority !== 'urgent' && inQuietHours(cfg.notify.quietHours)) {
    entry.status = 'held (quiet hours)';
    db.digestQueue.push(entry);
  } else {
    const r = await deliver(entry);
    entry.status = r.sent ? 'pushed' : r.errors.length ? `failed: ${r.errors.join('; ')}` : 'logged (no channel configured)';
  }
  db.alerts.unshift(entry);
  db.alerts = db.alerts.slice(0, 500);
  store.save();
  return entry;
}

// Called every tick: flush held alerts after quiet hours, and send the daily digest.
async function maintenance(now = new Date()) {
  const db = store.get();
  const cfg = config.get();
  if (db.digestQueue.length && !inQuietHours(cfg.notify.quietHours, now)) {
    const q = db.digestQueue.splice(0);
    const lines = q.slice(0, 15).map((x) => `• ${x.title}`);
    if (q.length > 15) lines.push(`…and ${q.length - 15} more`);
    await deliver({ title: `Overnight: ${q.length} penny alert(s)`, message: lines.join('\n'), priority: 'high', url: cfg.publicUrl || undefined, tags: ['sunrise'] });
    store.save();
  }
  const d = cfg.notify.dailyDigest;
  if (d?.enabled) {
    const today = now.toISOString().slice(0, 10);
    const due = now.getHours() * 60 + now.getMinutes() >= minutes(d.time);
    if (due && db.meta.lastDigest !== today) {
      db.meta.lastDigest = today;
      const since = now.getTime() - 86400000;
      const fresh = Object.values(db.pc.items).filter((i) => new Date(i.firstSeen).getTime() >= since)
        .sort((a, b) => (b.states || 0) - (a.states || 0));
      const { topHunt } = require('./watchlist');
      const hunt = topHunt(5);
      const lines = [];
      if (hunt.length) lines.push('Your watchlist:', ...hunt.map((h) => `• ${h.name} — score ${h.score}`));
      if (fresh.length) lines.push(`New on PennyCentral (${fresh.length}):`, ...fresh.slice(0, 8).map((i) => `• ${i.name} (${i.states ?? '?'} states)`));
      if (lines.length) await deliver({ title: 'Penny Radar daily digest', message: lines.join('\n'), priority: 'normal', url: cfg.publicUrl || undefined, tags: ['coin'] });
      store.save();
    }
  }
}

module.exports = { alert, deliver, maintenance, inQuietHours };

// Penny Radar — HTTP API + dashboard.
const express = require('express');
const path = require('path');
const config = require('./config');
const store = require('./store');
const jobs = require('./jobs');
const notify = require('./notify');
const watchlist = require('./watchlist');
const { decodeHD, decodeLowes, predict, score } = require('./engine/cadence');
const { normSku, formatSku } = require('./sources/pennycentral');

config.load();
store.load();

const app = express();
app.use(express.json({ limit: '256kb' }));

// Optional password (recommended if you expose the app beyond your home network).
const PASSWORD = process.env.APP_PASSWORD;
if (PASSWORD) {
  app.use((req, res, next) => {
    const h = req.headers.authorization || '';
    const [, b64] = h.split(' ');
    const pass = b64 ? Buffer.from(b64, 'base64').toString().split(':').slice(1).join(':') : '';
    if (pass === PASSWORD) return next();
    res.set('WWW-Authenticate', 'Basic realm="Penny Radar"').status(401).send('Password required');
  });
}

app.use(express.static(path.join(__dirname, '..', 'public')));

const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((e) => res.status(500).json({ error: e.message }));

app.get('/api/status', (req, res) => {
  const db = store.get();
  const cfg = config.get();
  res.json({
    jobs: jobs.status,
    pennycentral: { lastFetch: db.pc.lastFetch, lastError: db.pc.lastError, count: Object.values(db.pc.items).filter((i) => i.onList !== false).length },
    reddit: { lastFetch: db.reddit.lastFetch, lastError: db.reddit.lastError, count: db.reddit.posts.length },
    feeds: { lastFetch: db.feeds?.lastFetch, lastError: db.feeds?.lastError, count: db.feeds?.posts.length || 0, perFeed: db.feeds?.perFeed || {} },
    watchlist: db.watchlist.length,
    notify: { ntfy: cfg.notify.ntfy.enabled && !!cfg.notify.ntfy.topic, telegram: cfg.notify.telegram.enabled && !!cfg.notify.telegram.chatId },
    held: db.digestQueue.length,
  });
});

// Combined hunt list: everything worth a trip, best first.
app.get('/api/hunt', (req, res) => {
  const db = store.get();
  const items = [];
  for (const w of watchlist.list().filter((i) => !i.archived)) {
    items.push({ type: 'watch', id: w.id, name: w.name, sku: w.sku, store: w.store, storeName: w.storeName, score: w.score, reasons: w.reasons, links: w.links, prediction: w.prediction, latest: w.latest });
  }
  const dayAgo = Date.now() - 2 * 86400000;
  const watchedSkus = new Set(db.watchlist.map((w) => normSku(w.sku)).filter(Boolean));
  for (const p of Object.values(db.pc.items)) {
    if (p.onList === false || watchedSkus.has(p.sku)) continue; // watchlist card already includes it
    const s = score({ pcStates: p.states || 1 });
    items.push({ type: 'pennycentral', id: p.sku, name: p.name, sku: p.skuDisplay, store: 'homedepot', score: s.score, reasons: s.reasons,
      states: p.states, reports: p.reports, lastSeen: p.lastSeen, image: p.image, isNew: new Date(p.firstSeen).getTime() > dayAgo,
      links: { pennycentral: p.url, store: `https://www.homedepot.com/s/${p.sku}`, scavenger: 'https://scavenger.ai' } });
  }
  items.sort((a, b) => b.score - a.score || (b.states || 0) - (a.states || 0));
  res.json(items.slice(0, Number(req.query.limit) || 100));
});

app.get('/api/pennycentral', (req, res) => {
  const db = store.get();
  const q = String(req.query.q || '').toLowerCase();
  const min = Number(req.query.minStates) || 0;
  let items = Object.values(db.pc.items).filter((i) => i.onList !== false || req.query.all);
  if (q) items = items.filter((i) => `${i.name} ${i.sku} ${i.skuDisplay}`.toLowerCase().includes(q));
  if (min) items = items.filter((i) => (i.states || 0) >= min);
  items.sort((a, b) => new Date(b.firstSeen) - new Date(a.firstSeen) || (b.states || 0) - (a.states || 0));
  res.json(items.map(({ history, ...i }) => ({ ...i, trend: (history || []).map((h) => h.states) })));
});

app.get('/api/reddit', (req, res) => res.json(store.get().reddit.posts.slice(0, 100)));

// Forums tab: Reddit + RSS feeds merged, newest first. ?filter=penny|clearance|lowes|local
app.get('/api/posts', (req, res) => {
  const db = store.get();
  const all = [
    ...db.reddit.posts.map((p) => ({ ...p, source: `r/${p.sub}` })),
    ...(db.feeds?.posts || []).map((p) => ({ ...p, source: p.feed })),
  ];
  const f = req.query.filter;
  const list = all.filter((p) => !f || f === 'all'
    || (f === 'penny' && p.isPenny) || (f === 'glitch' && p.isGlitch) || (f === 'clearance' && p.isClearance && !p.isPenny)
    || (f === 'lowes' && (p.store === 'lowes' || /lowe/i.test(p.sub || ''))) || (f === 'local' && p.isLocal));
  list.sort((a, b) => new Date(b.created) - new Date(a.created));
  res.json(list.slice(0, 150));
});

app.get('/api/watchlist', (req, res) => res.json(watchlist.list()));
app.post('/api/watchlist', (req, res) => res.json(watchlist.add(req.body || {})));
app.patch('/api/watchlist/:id', (req, res) => { const r = watchlist.update(req.params.id, req.body || {}); r ? res.json(r) : res.sendStatus(404); });
app.delete('/api/watchlist/:id', (req, res) => { watchlist.remove(req.params.id); res.json({ ok: true }); });
app.post('/api/watchlist/:id/observations', (req, res) => { const r = watchlist.addObservation(req.params.id, req.body || {}); r ? res.json(r) : res.sendStatus(404); });

// Penny Check: everything we know about one SKU, plus a tag decode if a price is given.
app.get('/api/check', (req, res) => {
  const db = store.get();
  const sku = normSku(req.query.sku);
  const st = req.query.store === 'lowes' ? 'lowes' : 'homedepot';
  const price = req.query.price !== undefined && req.query.price !== '' ? Number(req.query.price) : null;
  const decoded = price === null ? null : st === 'lowes' ? decodeLowes(price, req.query.original) : decodeHD(price, { clearance: req.query.clearance !== 'false' });
  const prediction = decoded && st !== 'lowes' ? predict(decoded, req.query.tagDate || new Date()) : null;
  const pc = sku ? db.pc.items[sku] : null;
  const posts = sku ? [...db.reddit.posts, ...(db.feeds?.posts || [])].filter((p) => (p.skus || []).includes(sku)) : [];
  const watched = sku ? db.watchlist.find((w) => normSku(w.sku) === sku) : null;
  const s = score({ decoded, prediction, pcStates: pc ? pc.states || 1 : 0,   
    appNotFound: req.query.appNotFound === 'true', onlineUnavailable: req.query.onlineUnavailable === 'true', store: st,
    redditMentions: posts.filter((p) => p.isPenny).length });
  res.json({ sku, skuDisplay: sku ? formatSku(sku) : null, store: st, decoded, prediction, score: s.score, reasons: s.reasons,
    pennycentral: pc ? { name: pc.name, states: pc.states, reports: pc.reports, lastSeen: pc.lastSeen, url: pc.url, onList: pc.onList !== false } : null,
    reddit: posts.slice(0, 5), watchlistId: watched?.id || null, links: watchlist.links({ store: st, sku }) });
});

app.get('/api/alerts', (req, res) => res.json(store.get().alerts.slice(0, 200)));

app.get('/api/settings', (req, res) => res.json(config.get()));
app.put('/api/settings', (req, res) => res.json(config.save(req.body || {})));

app.post('/api/run/:job', wrap(async (req, res) => {
  const silent = req.query.silent === 'true';
  const map = { pennycentral: () => jobs.runPennyCentral({ silent }), reddit: () => jobs.runReddit({ silent }), feeds: () => jobs.runFeeds({ silent }), watchlist: () => jobs.runWatchlist() };
  if (!map[req.params.job]) return res.sendStatus(404);
  res.json(await map[req.params.job]());
}));

app.post('/api/test-alert', wrap(async (req, res) => {
  const r = await notify.alert({ title: 'Penny Radar test 🪙', message: 'If you can read this on your phone, alerts work.', priority: 'high', tags: ['white_check_mark'], url: config.get().publicUrl || undefined }, { force: true });
  res.json(r);
}));

const PORT = Number(process.env.PORT) || 8787;
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Penny Radar running on http://localhost:${PORT}`);
    if (process.env.NO_POLL !== '1') jobs.start();
  });
  const bye = () => { store.flush(); process.exit(0); };
  process.on('SIGINT', bye);
  process.on('SIGTERM', bye);
}

module.exports = app;

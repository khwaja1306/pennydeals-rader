// Tiny JSON-file database. Single process, debounced atomic writes.
const fs = require('fs');
const path = require('path');
const { DATA_DIR } = require('./config');

const DB_FILE = path.join(DATA_DIR, 'db.json');

const EMPTY = () => ({
  pc: { items: {}, lastFetch: null, lastError: null, seeded: false },
  reddit: { seen: {}, posts: [], lastFetch: null, lastError: null, seeded: false },
  feeds: { seen: {}, posts: [], seeded: {}, lastFetch: null, lastError: null, perFeed: {} },
  watchlist: [],
  alerts: [],
  sent: {},          // dedupe keys -> ISO time
  digestQueue: [],   // alerts held during quiet hours
  meta: { lastDigest: null },
});

let db = null;
let timer = null;

function load() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  try {
    db = { ...EMPTY(), ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) };
  } catch {
    db = EMPTY();
  }
  return db;
}

function get() { return db || load(); }

function flush() {
  if (!db) return;
  fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db));
  fs.renameSync(DB_FILE + '.tmp', DB_FILE);
}

function save() {
  clearTimeout(timer);
  timer = setTimeout(flush, 300);
}

function reset() { db = EMPTY(); flush(); }

module.exports = { get, load, save, flush, reset };
